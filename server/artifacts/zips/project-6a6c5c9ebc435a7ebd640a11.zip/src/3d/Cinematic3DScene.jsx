import React from 'react'
import { SceneContent } from './SceneComposer'

export default function Cinematic3DScene({ sceneId, style = {} }) {
  return (
    <SceneContent
      sceneId={sceneId || "FloatingBlobScene"}
      cameraPreset="Hero Camera"
      lightingPreset="Neon"
      interactionPreset="Morph"
      quality="High"
    />
  )
}
import React, { createContext, useContext, useState, useMemo } from 'react';
import tokens from './tokens';
import apple from './themes/apple';
import vercel from './themes/vercel';
import linear from './themes/linear';
import stripe from './themes/stripe';
import framer from './themes/framer';
import notion from './themes/notion';
import minimal from './themes/minimal';
import modernDark from './themes/modernDark';

const THEME_REGISTRY = {
  apple,
  vercel,
  linear,
  stripe,
  framer,
  notion,
  minimal,
  modernDark,
  "Cyberpunk": {
    name: "Cyberpunk",
    colors: {
  "primary": "#00ffff",
  "secondary": "#ff007f",
  "accent": "#fee801",
  "background": "#050508",
  "surface": "#0f0f18",
  "text": "#ffffff",
  "textMuted": "#a1a1aa"
},
    button: { radius: 'xl', shadow: 'none', style: 'default' },
    card: { radius: 'lg', shadow: 'none', bg: 'surface', border: true },
    hero: { badgeBg: 'rgba(61, 94, 255, 0.2)', badgeText: '#00d4ff', align: 'left' }
  },
};

const ThemeContext = createContext({
  currentTheme: 'Cyberpunk',
  themeTokens: tokens,
  setTheme: () => {}
});

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    return { currentTheme: 'Cyberpunk', themeTokens: tokens, setTheme: () => {} };
  }
  return context;
};

export function ThemeProvider({ initialTheme = 'Cyberpunk', children }) {
  const [currentTheme, setCurrentTheme] = useState(() => {
    return THEME_REGISTRY[initialTheme] ? initialTheme : 'Cyberpunk';
  });

  const themeTokens = useMemo(() => {
    const selected = THEME_REGISTRY[currentTheme] || THEME_REGISTRY.modernDark || {};
    return {
      ...tokens,
      ...selected,
      colors: { ...tokens.colors, ...(selected.colors || {}) },
      spacing: { ...tokens.spacing, ...(selected.spacing || {}) },
      radius: { ...tokens.radius, ...(selected.radius || {}) },
      shadows: { ...tokens.shadows, ...(selected.shadows || {}) },
      typography: { ...tokens.typography, ...(selected.typography || {}) },
      animations: { ...tokens.animations, ...(selected.animations || {}) },
      button: { ...tokens.button, ...(selected.button || {}) },
      card: { ...tokens.card, ...(selected.card || {}) },
      hero: { ...tokens.hero, ...(selected.hero || {}) },
    };
  }, [currentTheme]);

  const value = useMemo(() => ({
    currentTheme,
    themeTokens,
    setTheme: setCurrentTheme
  }), [currentTheme, themeTokens]);

  const cssVariables = useMemo(() => ({
    '--color-primary': themeTokens.colors.primary,
    '--color-secondary': themeTokens.colors.secondary,
    '--color-accent': themeTokens.colors.accent,
    '--color-background': themeTokens.colors.background,
    '--color-surface': themeTokens.colors.surface,
    '--color-border': themeTokens.colors.border,
    '--color-text': themeTokens.colors.text,
    '--color-text-muted': themeTokens.colors.textMuted,
  }), [themeTokens]);

  return (
    <ThemeContext.Provider value={value}>
      <div style={{ ...cssVariables, backgroundColor: themeTokens.colors.background, color: themeTokens.colors.text, minHeight: '100vh', transition: 'background-color 0.3s ease, color 0.3s ease' }}>
        {children}
      </div>
    </ThemeContext.Provider>
  );
}

export default ThemeProvider;

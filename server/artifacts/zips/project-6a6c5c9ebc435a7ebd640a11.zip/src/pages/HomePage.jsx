import React from 'react';
import HeroSection from '../components/sections/HeroSection';
import FeaturesSection from '../components/sections/FeaturesSection';
import GallerySection from '../components/sections/GallerySection';
import CTASection from '../components/sections/CTASection';
import TestimonialsSection from '../components/sections/TestimonialsSection';
import FAQSection from '../components/sections/FAQSection';
import ContactSection from '../components/sections/ContactSection';

export default function HomePage() {
  return (
    <div className="page-home">
      <HeroSection />
      <FeaturesSection />
      <GallerySection />
      <CTASection title="Experience the Future of Driving" subtitle="Configure your vehicle or schedule an exclusive test drive today." buttonText="Book Test Drive" />
      <TestimonialsSection />
      <FAQSection />
      <ContactSection />
    </div>
  );
}

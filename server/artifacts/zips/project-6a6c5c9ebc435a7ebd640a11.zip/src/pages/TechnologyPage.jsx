import React from 'react';
import Section from '../components/layout/Section';
import Container from '../components/layout/Container';
import Grid from '../components/layout/Grid';
import Stack from '../components/layout/Stack';

export default function TechnologyPage() {
  const items = [
  {
    "title": "Autonomous Intelligent Workflows",
    "desc": "Advanced operating features engineered to streamline collaboration and optimize everyday processes effortlessly.",
    "icon": "⚡"
  },
  {
    "title": "Seamless Visual Interaction",
    "desc": "Responsive high-resolution interface designed to provide immediate clarity, fluidity, and intuitive interaction across any endpoint.",
    "icon": "🌐"
  },
  {
    "title": "Uncompromising Security Standard",
    "desc": "Enterprise-grade data encryption, robust authentication frameworks, and reliable system resilience built from the ground up.",
    "icon": "🔒"
  },
  {
    "title": "Real-Time Synchronization",
    "desc": "Instant collaborative updates and reliable connectivity that keeps all participants perfectly aligned in real time.",
    "icon": "🤝"
  }
];

  return (
    <div className="page-technology">
      <Section spacing="lg">
        <Container size="lg">
          <Stack spacing="lg">
            <div className="mb-6 border-b border-slate-800/80 pb-10">
              <span className="text-xs uppercase font-extrabold tracking-widest text-indigo-400 block mb-3">Dedicated Domain Showcase</span>
              <h1 className="text-4xl md:text-5xl font-black mb-5 tracking-tight text-white">Technology Features</h1>
              <p className="text-lg md:text-xl text-slate-300 leading-relaxed max-w-3xl">
                An interactive catalog of our specialized offerings, professional standards, and verified features within our technology division.
              </p>
            </div>
            <Grid columns={2} gap="md">
              {items.map((it, idx) => (
                <div key={idx} className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800/80 hover:border-indigo-500/50 transition-all shadow-xl flex items-start gap-6">
                  <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-2xl shrink-0">{it.icon || '✦'}</div>
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-3">{it.title}</h3>
                    <p className="text-slate-400 leading-relaxed text-sm">{it.desc}</p>
                  </div>
                </div>
              ))}
            </Grid>
          </Stack>
        </Container>
      </Section>
    </div>
  );
}

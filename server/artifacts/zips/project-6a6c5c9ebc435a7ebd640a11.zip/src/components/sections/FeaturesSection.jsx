import React from 'react';
import FeatureCard from '../ui/FeatureCard';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Grid from '../layout/Grid';
import Stack from '../layout/Stack';

export default function FeaturesSection() {
  const features = [
  {
    "icon": "⚡",
    "title": "Autonomous Orchestration",
    "description": "Intelligent background workflows that monitor, repair, and optimize system pipelines."
  },
  {
    "icon": "🌐",
    "title": "Zero-Latency Spatial UI",
    "description": "Hardware-accelerated 3D rendering engine built to provide responsive interactions."
  },
  {
    "icon": "🔒",
    "title": "Enterprise Grade Security",
    "description": "End-to-end cryptographic verifications and SOC-2 certified cloud storage."
  },
  {
    "icon": "🤝",
    "title": "Real-time Collaboration",
    "description": "Multi-user websocket concurrency enabling seamless global teamwork."
  }
];

  return (
    <Section id="features" spacing="lg">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[var(--color-secondary,#00d4ff)] mb-2 block">Features</span>
            <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-[var(--color-text,#f0f0ff)] mb-4">Features</h2>
            <p className="text-[var(--color-text-muted,#94a3b8)] text-lg max-w-2xl mx-auto">Uncompromised performance standards.</p>
          </div>
          <Grid columns={2} gap="md">
            {features.map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon} title={f.title} description={f.description} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Grid from '../layout/Grid';
import Stack from '../layout/Stack';

export default function GallerySection() {
  const items = [];

  return (
    <Section id="gallery" spacing="lg">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-indigo-400 mb-2 block">Immersive Showcase</span>
            <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-4">Visual Gallery</h2>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">Take a glimpse inside our sanctuary of elevated aesthetics.</p>
          </div>
          <Grid columns={2} gap="md">
            {items.map((item, idx) => (
              <div key={idx} className="group relative h-72 rounded-3xl overflow-hidden bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 p-8 flex flex-col justify-end transition-all duration-300 hover:border-indigo-500/50 hover:shadow-2xl">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-indigo-600/20 via-slate-950/60 to-slate-950 transition-opacity duration-300 opacity-70 group-hover:opacity-100"></div>
                <div className="relative z-10">
                  <span className="text-xs font-semibold uppercase text-indigo-400 tracking-widest mb-1 block">{item.subtitle}</span>
                  <h3 className="text-2xl font-bold text-white group-hover:text-cyan-300 transition-colors">{item.title}</h3>
                </div>
              </div>
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

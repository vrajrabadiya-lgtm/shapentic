import React from 'react'
import HeroLayout from '../layout/HeroLayout'
import Cinematic3DScene from '../../3d/Cinematic3DScene'

const heroData = {
  "title": "The Future of Performance",
  "subtitle": "Discover next-generation automotive design merging sustainable power with unparalleled track performance and autonomous intelligence.",
  "description": "Discover next-generation automotive design merging sustainable power with unparalleled track performance and autonomous intelligence.",
  "badge": "Zero Emissions · Peak Performance",
  "alignment": "left",
  "background": "#050508",
  "theme": {
    "primary": "#00ffff",
    "secondary": "#ff007f",
    "text": "#ffffff"
  },
  "buttons": [
    {
      "text": "Explore Apex F1 Racing",
      "variant": "primary"
    }
  ]
}

export default function HeroSection() {
  return (
    <HeroLayout
      {...heroData}
      scene={<Cinematic3DScene />}
    />
  )
}

import React from 'react';
import FAQAccordion from '../ui/FAQAccordion';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';

export default function FAQSection() {
  const faqs = [
  {
    "question": "How rapidly can we implement this workflow into our existing infrastructure?",
    "answer": "Our modular architecture defaults to REST and GraphQL endpoints that plug directly into existing stacks within 48 hours."
  },
  {
    "question": "What security compliance certifications do your platforms maintain?",
    "answer": "We maintain SOC-2 Type II, ISO 27001, and HIPAA compliant infrastructure architectures."
  },
  {
    "question": "Can we customize the 3D rendering pipeline?",
    "answer": "Yes, the custom shader and parser pipeline ingests standard CAD and spatial formats."
  }
];

  return (
    <Section id="faq" spacing="lg">
      <Container size="md">
        <Stack spacing="lg">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[var(--color-secondary,#00d4ff)] mb-2 block">Clear Answers</span>
            <h2 className="text-4xl font-extrabold text-[var(--color-text,#f0f0ff)] tracking-tight mb-4">FAQ</h2>
            <p className="text-[var(--color-text-muted,#94a3b8)] text-base max-w-xl mx-auto">Everything you need to know about system integrations.</p>
          </div>
          <Stack spacing="sm">
            {faqs.map((item, idx) => (
              <FAQAccordion key={idx} question={item.question} answer={item.answer} defaultOpen={idx === 0} icon="+" />
            ))}
          </Stack>
        </Stack>
      </Container>
    </Section>
  );
}

import React from 'react';
import TestimonialCard from '../ui/TestimonialCard';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Grid from '../layout/Grid';
import Stack from '../layout/Stack';

export default function TestimonialsSection() {
  const testimonials = [];

  return (
    <Section id="testimonials" spacing="lg">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[var(--color-secondary,#00d4ff)] mb-2 block">Verified Excellence</span>
            <h2 className="text-4xl md:text-5xl font-extrabold text-[var(--color-text,#f0f0ff)] mb-4 tracking-tight">What Our Clients Say</h2>
            <p className="text-[var(--color-text-muted,#94a3b8)] text-lg max-w-2xl mx-auto">Discover authentic perspectives from industry leaders, taste makers, and valued partners.</p>
          </div>
          <Grid columns={3} gap="md">
            {testimonials.map((rev, idx) => (
              <TestimonialCard key={idx} {...rev} animation={{ delay: idx * 0.15 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

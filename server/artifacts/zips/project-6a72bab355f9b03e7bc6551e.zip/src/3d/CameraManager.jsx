import React, { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { PerspectiveCamera, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

export default function CameraManager({ preset = "Hero Camera", interactive = true }) {
  const cameraRef = useRef();
  const controlsRef = useRef();

  useEffect(() => {
    if (!cameraRef.current) return;
    const cam = cameraRef.current;
    switch (preset) {
      case "Hero Camera":
        cam.position.set(0, 0, 7.5);
        cam.fov = 45;
        break;
      case "Orbit Camera":
        cam.position.set(6, 3, 6);
        cam.fov = 50;
        break;
      case "Product Camera":
        cam.position.set(0, 2.5, 5.5);
        cam.fov = 40;
        break;
      case "Close-up":
        cam.position.set(0, 0.5, 3.8);
        cam.fov = 38;
        break;
      case "Wide":
        cam.position.set(0, 1.5, 12);
        cam.fov = 60;
        break;
      case "Scroll Camera":
        cam.position.set(0, 4, 8);
        cam.fov = 48;
        break;
      default:
        cam.position.set(0, 0, 7.5);
        cam.fov = 45;
    }
    cam.updateProjectionMatrix();
  }, [preset]);

  useFrame(({ clock, mouse }) => {
    if (!cameraRef.current || preset === "Orbit Camera") return;
    const elapsedTime = clock.getElapsedTime();
    if (preset === "Hero Camera" || preset === "Close-up" || preset === "Product Camera") {
      const targetX = mouse.x * 0.45;
      const targetY = -mouse.y * 0.35 + (preset === "Product Camera" ? 2.5 : 0);
      cameraRef.current.position.x += (targetX - cameraRef.current.position.x) * 0.04;
      cameraRef.current.position.y += (targetY - cameraRef.current.position.y) * 0.04;
      cameraRef.current.lookAt(0, 0, 0);
    } else if (preset === "Scroll Camera") {
      cameraRef.current.position.y = 4 + Math.sin(elapsedTime * 0.5) * 0.3;
      cameraRef.current.lookAt(0, 0, 0);
    }
  });

  return (
    <>
      <PerspectiveCamera ref={cameraRef} makeDefault position={[0, 0, 7.5]} />
      {interactive && preset === "Orbit Camera" && <OrbitControls ref={controlsRef} enableZoom={false} enablePan={false} maxPolarAngle={Math.PI / 1.6} />}
    </>
  );
}

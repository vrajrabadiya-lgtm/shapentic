import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function NeonTunnelScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#f43f5e" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  

  return (
    <group ref={meshRef}>
      
      {/* Particles & Clouds */}
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[particlePositions, 3]} />
        </bufferGeometry>
        <pointsMaterial color={color} size={0.07} transparent opacity={0.85} sizeAttenuation />
      </points>
      
    </group>
  );
}

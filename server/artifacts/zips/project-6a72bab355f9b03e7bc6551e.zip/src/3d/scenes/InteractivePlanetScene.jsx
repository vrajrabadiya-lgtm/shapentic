import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function InteractivePlanetScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#3b82f6" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  

  return (
    <group ref={meshRef}>
      
      <mesh castShadow receiveShadow>
        <sphereGeometry args={[2.2, segs, segs]} />
        <meshStandardMaterial color={color} roughness={0.25} metalness={0.7} wireframe={false} />
      </mesh>
      
      <mesh scale={1.05}>
        <sphereGeometry args={[2.2, segs / 2, segs / 2]} />
        <meshBasicMaterial color="#ffffff" wireframe transparent opacity={0.15} />
      </mesh>
      
    </group>
  );
}

import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function EnergyCoreScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#ec4899" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  

  return (
    <group ref={meshRef}>
      
      <mesh>
        <octahedronGeometry args={[2.0, 2]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.6} roughness={0.2} />
      </mesh>
      <mesh rotation={[0, Math.PI / 4, 0]} scale={1.3}>
        <icosahedronGeometry args={[2.0, 1]} />
        <meshBasicMaterial color="#ffffff" wireframe transparent opacity={0.3} />
      </mesh>
      
    </group>
  );
}

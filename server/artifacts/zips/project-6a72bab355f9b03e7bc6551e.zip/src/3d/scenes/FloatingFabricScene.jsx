import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function FloatingFabricScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#ec4899" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  

  return (
    <group ref={meshRef}>
      
      <mesh castShadow receiveShadow>
        <sphereGeometry args={[2.2, segs, segs]} />
        <meshStandardMaterial color={color} roughness={0.25} metalness={0.7} wireframe={false} />
      </mesh>
      
      
    </group>
  );
}

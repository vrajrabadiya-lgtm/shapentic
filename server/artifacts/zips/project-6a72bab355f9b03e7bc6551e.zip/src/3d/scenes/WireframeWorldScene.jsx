import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function WireframeWorldScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#06b6d4" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  

  return (
    <group ref={meshRef}>
      
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2, 0]}>
        <planeGeometry args={[20, 20, 20, 20]} />
        <meshStandardMaterial color={color} wireframe emissive={color} emissiveIntensity={0.3} />
      </mesh>
      <mesh>
        <sphereGeometry args={[1.8, 32, 32]} />
        <meshStandardMaterial color="#ffffff" roughness={0.3} metalness={0.8} wireframe={true} />
      </mesh>
      
    </group>
  );
}

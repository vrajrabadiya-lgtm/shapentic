import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function MedicalMoleculesScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#38bdf8" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  
  const particlePositions = useMemo(() => {
    const count = 300;
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count * 3; i += 3) {
      arr[i] = (Math.random() - 0.5) * 10;
      arr[i + 1] = (Math.random() - 0.5) * 10;
      arr[i + 2] = (Math.random() - 0.5) * 10;
    }
    return arr;
  }, []);
  

  return (
    <group ref={meshRef}>
      
      {/* Particles & Clouds */}
      <points>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" args={[particlePositions, 3]} />
        </bufferGeometry>
        <pointsMaterial color={color} size={0.07} transparent opacity={0.85} sizeAttenuation />
      </points>
      
    </group>
  );
}

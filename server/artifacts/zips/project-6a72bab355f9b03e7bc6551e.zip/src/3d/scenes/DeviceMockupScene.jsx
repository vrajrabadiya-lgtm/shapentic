import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function DeviceMockupScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#94a3b8" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  

  return (
    <group ref={meshRef}>
      
      <mesh castShadow receiveShadow>
        <boxGeometry args={[3.2, 2.2, 0.4]} />
        <meshStandardMaterial color={color} roughness={0.3} metalness={0.6} />
      </mesh>
      <mesh position={[0, 0, 0.25]} scale={0.95}>
        <boxGeometry args={[3.2, 2.2, 0.05]} />
        <meshBasicMaterial color="#ffffff" wireframe={false} transparent opacity={0.2} />
      </mesh>
      
    </group>
  );
}

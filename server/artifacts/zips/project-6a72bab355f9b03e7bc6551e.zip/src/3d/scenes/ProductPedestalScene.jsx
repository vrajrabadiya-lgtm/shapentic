import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function ProductPedestalScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#e2e8f0" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  

  return (
    <group ref={meshRef}>
      
      <mesh rotation={[Math.PI / 3, 0, 0]}>
        <torusGeometry args={[2.5, 0.18, segs / 2, segs]} />
        <meshStandardMaterial color={color} metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh rotation={[-Math.PI / 4, 0, 0]} scale={0.8}>
        <torusGeometry args={[2.5, 0.12, segs / 2, segs]} />
        <meshStandardMaterial color="#ffffff" metalness={0.9} roughness={0.1} />
      </mesh>
      
    </group>
  );
}

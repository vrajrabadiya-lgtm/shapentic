import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useInteractionPreset } from '../InteractionPresets';
import * as THREE from 'three';

export default function GlassOrbScene({ interactionPreset = "Hover Rotation", qualityProfile = { geometrySegments: 64 }, color = "#60a5fa" }) {
  const meshRef = useRef();
  useInteractionPreset(meshRef, interactionPreset);

  const segs = qualityProfile.geometrySegments || 64;

  

  return (
    <group ref={meshRef}>
      
      <mesh castShadow receiveShadow>
        <sphereGeometry args={[2.3, segs, segs]} />
        <meshPhysicalMaterial color={color} transmission={0.9} opacity={1} transparent roughness={0.1} ior={1.5} thickness={0.5} />
      </mesh>
      
    </group>
  );
}

import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export function useInteractionPreset(ref, preset = "Hover Rotation", speedMultiplier = 1.0) {
  useFrame(({ clock, mouse, camera }) => {
    if (!ref.current) return;
    const elapsed = clock.getElapsedTime() * speedMultiplier;

    switch (preset) {
      case "Mouse Follow":
        ref.current.rotation.y = THREE.MathUtils.lerp(ref.current.rotation.y, mouse.x * 0.8, 0.05);
        ref.current.rotation.x = THREE.MathUtils.lerp(ref.current.rotation.x, -mouse.y * 0.8, 0.05);
        break;
      case "Scroll Rotation":
        ref.current.rotation.y = elapsed * 0.4;
        ref.current.rotation.x = Math.sin(elapsed * 0.3) * 0.3;
        break;
      case "Parallax":
        ref.current.position.x = THREE.MathUtils.lerp(ref.current.position.x, mouse.x * 0.6, 0.06);
        ref.current.position.y = THREE.MathUtils.lerp(ref.current.position.y, -mouse.y * 0.6, 0.06);
        break;
      case "Idle Float":
        ref.current.position.y = Math.sin(elapsed * 1.5) * 0.3;
        ref.current.rotation.y = elapsed * 0.2;
        break;
      case "Pulse":
        const scale = 1.0 + Math.sin(elapsed * 2.8) * 0.08;
        ref.current.scale.set(scale, scale, scale);
        ref.current.rotation.y = elapsed * 0.25;
        break;
      case "Morph":
        ref.current.rotation.y = elapsed * 0.3;
        ref.current.rotation.z = Math.sin(elapsed * 0.8) * 0.25;
        break;
      case "Reveal":
        ref.current.rotation.y = elapsed * 0.15;
        break;
      case "Hover Rotation":
      default:
        ref.current.rotation.y += 0.008 * speedMultiplier;
        ref.current.rotation.x = Math.sin(elapsed * 0.5) * 0.15;
        break;
    }
  });
}

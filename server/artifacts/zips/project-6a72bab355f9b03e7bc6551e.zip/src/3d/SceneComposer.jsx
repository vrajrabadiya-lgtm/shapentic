import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Stars, Float } from '@react-three/drei';
import { EffectComposer, Bloom } from '@react-three/postprocessing';
import CameraManager from './CameraManager';
import LightingPresets from './LightingPresets';
import { getQualityProfile } from './PerformanceManager';

// Import All 35 Reusable Scenes
import FloatingBlobScene from './scenes/FloatingBlobScene';
import GlassOrbScene from './scenes/GlassOrbScene';
import ParticleGalaxyScene from './scenes/ParticleGalaxyScene';
import EnergyCoreScene from './scenes/EnergyCoreScene';
import OrbitRingScene from './scenes/OrbitRingScene';
import GradientCloudScene from './scenes/GradientCloudScene';
import WireframeWorldScene from './scenes/WireframeWorldScene';
import FloatingCardsScene from './scenes/FloatingCardsScene';
import DashboardScene from './scenes/DashboardScene';
import ProductPedestalScene from './scenes/ProductPedestalScene';
import ConstellationScene from './scenes/ConstellationScene';
import LightBeamScene from './scenes/LightBeamScene';
import GridFloorScene from './scenes/GridFloorScene';
import LiquidSphereScene from './scenes/LiquidSphereScene';
import GlassCubeScene from './scenes/GlassCubeScene';
import FloatingIconsScene from './scenes/FloatingIconsScene';
import HologramScene from './scenes/HologramScene';
import NeonTunnelScene from './scenes/NeonTunnelScene';
import DeviceMockupScene from './scenes/DeviceMockupScene';
import InteractivePlanetScene from './scenes/InteractivePlanetScene';
import FloatingFoodScene from './scenes/FloatingFoodScene';
import RotatingPlateScene from './scenes/RotatingPlateScene';
import SteamScene from './scenes/SteamScene';
import FloatingIngredientsScene from './scenes/FloatingIngredientsScene';
import DNAHelixScene from './scenes/DNAHelixScene';
import MedicalMoleculesScene from './scenes/MedicalMoleculesScene';
import HeartbeatScene from './scenes/HeartbeatScene';
import VehicleShowcaseScene from './scenes/VehicleShowcaseScene';
import TurntableScene from './scenes/TurntableScene';
import ReflectionFloorScene from './scenes/ReflectionFloorScene';
import FloatingSkillsScene from './scenes/FloatingSkillsScene';
import FloatingFabricScene from './scenes/FloatingFabricScene';
import LuxuryLightingScene from './scenes/LuxuryLightingScene';
import GlassObjectsScene from './scenes/GlassObjectsScene';
import AnimatedTimelineScene from './scenes/AnimatedTimelineScene';

const SCENE_COMPONENTS = {
  FloatingBlobScene: FloatingBlobScene,
  GlassOrbScene: GlassOrbScene,
  ParticleGalaxyScene: ParticleGalaxyScene,
  EnergyCoreScene: EnergyCoreScene,
  OrbitRingScene: OrbitRingScene,
  GradientCloudScene: GradientCloudScene,
  WireframeWorldScene: WireframeWorldScene,
  FloatingCardsScene: FloatingCardsScene,
  DashboardScene: DashboardScene,
  ProductPedestalScene: ProductPedestalScene,
  ConstellationScene: ConstellationScene,
  LightBeamScene: LightBeamScene,
  GridFloorScene: GridFloorScene,
  LiquidSphereScene: LiquidSphereScene,
  GlassCubeScene: GlassCubeScene,
  FloatingIconsScene: FloatingIconsScene,
  HologramScene: HologramScene,
  NeonTunnelScene: NeonTunnelScene,
  DeviceMockupScene: DeviceMockupScene,
  InteractivePlanetScene: InteractivePlanetScene,
  FloatingFoodScene: FloatingFoodScene,
  RotatingPlateScene: RotatingPlateScene,
  SteamScene: SteamScene,
  FloatingIngredientsScene: FloatingIngredientsScene,
  DNAHelixScene: DNAHelixScene,
  MedicalMoleculesScene: MedicalMoleculesScene,
  HeartbeatScene: HeartbeatScene,
  VehicleShowcaseScene: VehicleShowcaseScene,
  TurntableScene: TurntableScene,
  ReflectionFloorScene: ReflectionFloorScene,
  FloatingSkillsScene: FloatingSkillsScene,
  FloatingFabricScene: FloatingFabricScene,
  LuxuryLightingScene: LuxuryLightingScene,
  GlassObjectsScene: GlassObjectsScene,
  AnimatedTimelineScene: AnimatedTimelineScene,
};

export function SceneContent({
  sceneId = "FloatingBlobScene",
  cameraPreset = "Hero Camera",
  lightingPreset = "Studio",
  interactionPreset = "Hover Rotation",
  quality = "High",
  primaryColor = "#3b82f6",
  secondaryColor = "#10b981"
}) {
  const TargetScene = SCENE_COMPONENTS[sceneId] || SCENE_COMPONENTS.FloatingBlobScene;
  const profile = getQualityProfile(quality);

  return (
    <Suspense fallback={null}>
      <CameraManager preset={cameraPreset} interactive={true} />
      <LightingPresets preset={lightingPreset} primaryColor={primaryColor} secondaryColor={secondaryColor} />
      
      {quality !== "Low" && <Stars radius={80} depth={50} count={profile.particleCount} factor={4} fade speed={1} />}

      <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.8}>
        <TargetScene interactionPreset={interactionPreset} qualityProfile={profile} color={primaryColor} />
      </Float>

      {profile.bloom && (
        <EffectComposer>
          <Bloom luminanceThreshold={0.4} luminanceSmoothing={0.9} height={300} intensity={profile.bloomIntensity} />
        </EffectComposer>
      )}
    </Suspense>
  );
}

export default function SceneComposer({
  sceneId = "FloatingBlobScene",
  cameraPreset = "Hero Camera",
  lightingPreset = "Studio",
  interactionPreset = "Hover Rotation",
  quality = "High",
  primaryColor = "#3b82f6",
  secondaryColor = "#10b981",
  style = {}
}) {
  const profile = getQualityProfile(quality);

  return (
    <div className="w-full h-full relative pointer-events-auto" style={{ minHeight: '400px', ...style }}>
      <Canvas
        shadows={profile.shadows}
        dpr={profile.pixelRatio}
        gl={{ alpha: true, antialias: quality !== "Low" }}
        className="!absolute inset-0 w-full h-full"
      >
        <SceneContent
          sceneId={sceneId}
          cameraPreset={cameraPreset}
          lightingPreset={lightingPreset}
          interactionPreset={interactionPreset}
          quality={quality}
          primaryColor={primaryColor}
          secondaryColor={secondaryColor}
        />
      </Canvas>
    </div>
  );
}

export const PERFORMANCE_PROFILES = {
  High: {
    bloom: true,
    bloomIntensity: 1.2,
    particleCount: 1500,
    geometrySegments: 64,
    shadows: true,
    pixelRatio: Math.min(typeof window !== 'undefined' ? window.devicePixelRatio : 2, 2)
  },
  Medium: {
    bloom: true,
    bloomIntensity: 0.7,
    particleCount: 700,
    geometrySegments: 32,
    shadows: false,
    pixelRatio: 1.5
  },
  Low: {
    bloom: false,
    bloomIntensity: 0,
    particleCount: 250,
    geometrySegments: 16,
    shadows: false,
    pixelRatio: 1.0
  }
};

export function getQualityProfile(level = "High") {
  return PERFORMANCE_PROFILES[level] || PERFORMANCE_PROFILES.High;
}

export const colors = {
  primary: '#3d5eff',
  secondary: '#00d4ff',
  accent: '#ff007f',
  background: '#0a0a14',
  surface: '#131424',
  border: 'rgba(255, 255, 255, 0.12)',
  text: '#ffffff',
  textMuted: '#94a3b8'
};

export const spacing = {
  xs: '0.5rem',
  sm: '0.75rem',
  md: '1rem',
  lg: '1.5rem',
  xl: '2rem',
  '2xl': '3rem',
  '3xl': '4rem'
};

export const radius = {
  none: '0px',
  sm: '0.25rem',
  md: '0.5rem',
  lg: '0.75rem',
  xl: '1rem',
  full: '9999px'
};

export const shadows = {
  none: 'none',
  sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
  md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
  lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
  xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
  glow: '0 0 25px rgba(61, 94, 255, 0.25)'
};

export const typography = {
  display: 'text-5xl md:text-6xl font-black tracking-tight',
  heading: 'text-3xl md:text-4xl font-bold tracking-tight',
  title: 'text-xl md:text-2xl font-semibold',
  subtitle: 'text-lg md:text-xl font-medium',
  body: 'text-base leading-relaxed',
  caption: 'text-sm font-medium opacity-80',
  code: 'font-mono text-sm px-2 py-1 bg-black/30 rounded'
};

export const animations = {
  fadeUp: { initial: { opacity: 0, y: 24 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.5 } },
  fadeDown: { initial: { opacity: 0, y: -24 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.5 } },
  fadeLeft: { initial: { opacity: 0, x: 24 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.5 } },
  fadeRight: { initial: { opacity: 0, x: -24 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.5 } },
  zoom: { initial: { opacity: 0, scale: 0.9 }, whileInView: { opacity: 1, scale: 1 }, viewport: { once: true }, transition: { duration: 0.4 } },
  scale: { whileHover: { scale: 1.03 }, whileTap: { scale: 0.98 }, transition: { duration: 0.2 } },
  stagger: (index = 0) => ({ initial: { opacity: 0, y: 20 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true }, transition: { duration: 0.4, delay: index * 0.1 } })
};

export const transitions = {
  fast: '0.15s ease',
  normal: '0.25s ease',
  slow: '0.4s ease'
};

export const zIndex = {
  base: 1,
  dropdown: 10,
  sticky: 50,
  modal: 100
};

export const breakpoints = {
  sm: '640px',
  md: '768px',
  lg: '1024px',
  xl: '1280px',
  '2xl': '1536px'
};

export default {
  colors,
  spacing,
  radius,
  shadows,
  typography,
  animations,
  transitions,
  zIndex,
  breakpoints,
  button: { radius: 'xl', shadow: 'none', style: 'default' },
  card: { radius: 'lg', shadow: 'none', bg: 'surface', border: true },
  hero: { badgeBg: 'rgba(61, 94, 255, 0.2)', badgeText: '#00d4ff', align: 'left' }
};

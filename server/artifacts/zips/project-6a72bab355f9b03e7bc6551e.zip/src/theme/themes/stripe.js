export default {
  name: "stripe",
  colors: {
    primary: '#635bff',
    secondary: '#00d4ff',
    accent: '#00d924',
    background: '#f6f9fc',
    surface: '#ffffff',
    border: 'rgba(0, 0, 0, 0.06)',
    text: '#0a2540',
    textMuted: '#425466'
  },
  button: {
    radius: 'lg',
    shadow: 'md',
    style: 'stripe',
    className: 'rounded-xl bg-[#635bff] text-white shadow-lg font-bold'
  },
  card: {
    radius: 'lg',
    shadow: 'xl',
    bg: '#ffffff',
    border: false,
    className: 'bg-white rounded-xl shadow-xl border-0 transform transition-transform duration-300 hover:-translate-y-1'
  },
  hero: {
    badgeBg: 'rgba(99, 91, 255, 0.1)',
    badgeText: '#635bff',
    align: 'left'
  }
};

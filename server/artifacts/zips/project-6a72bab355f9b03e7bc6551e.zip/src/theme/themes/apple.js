export default {
  name: "apple",
  colors: {
    primary: '#0071e3',
    secondary: '#147ce5',
    accent: '#ff3b30',
    background: '#f5f5f7',
    surface: '#ffffff',
    border: 'rgba(0, 0, 0, 0.08)',
    text: '#1d1d1f',
    textMuted: '#6e6e73'
  },
  button: {
    radius: 'full',
    shadow: 'sm',
    style: 'apple',
    className: 'rounded-full font-medium tracking-normal'
  },
  card: {
    radius: 'xl',
    shadow: 'md',
    bg: '#ffffff',
    border: false,
    className: 'bg-white rounded-2xl shadow-md border-0'
  },
  hero: {
    badgeBg: 'rgba(0, 113, 227, 0.1)',
    badgeText: '#0071e3',
    align: 'center'
  },
  radius: {
    none: '0px',
    sm: '0.5rem',
    md: '0.75rem',
    lg: '1rem',
    xl: '1.5rem',
    full: '9999px'
  }
};

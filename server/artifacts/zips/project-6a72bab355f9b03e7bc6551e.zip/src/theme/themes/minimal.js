export default {
  name: "minimal",
  colors: {
    primary: '#000000',
    secondary: '#444444',
    accent: '#000000',
    background: '#ffffff',
    surface: '#f9f9f9',
    border: '#cccccc',
    text: '#000000',
    textMuted: '#666666'
  },
  button: {
    radius: 'none',
    shadow: 'none',
    style: 'minimal',
    className: 'rounded-none border border-black bg-black text-white font-bold uppercase tracking-widest text-xs py-3 px-6 hover:bg-white hover:text-black transition-colors'
  },
  card: {
    radius: 'none',
    shadow: 'none',
    bg: '#f9f9f9',
    border: true,
    className: 'bg-[#f9f9f9] border border-black/20 rounded-none shadow-none'
  },
  hero: {
    badgeBg: '#eeeeee',
    badgeText: '#000000',
    align: 'left'
  },
  radius: {
    none: '0px',
    sm: '0px',
    md: '0px',
    lg: '0px',
    xl: '0px',
    full: '0px'
  }
};

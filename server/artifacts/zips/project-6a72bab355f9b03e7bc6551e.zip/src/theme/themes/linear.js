export default {
  name: "linear",
  colors: {
    primary: '#5e6ad2',
    secondary: '#00c6ff',
    accent: '#ff007a',
    background: '#08090a',
    surface: '#1c1d22',
    border: 'rgba(255, 255, 255, 0.08)',
    text: '#f7f8f8',
    textMuted: '#8d99ae'
  },
  button: {
    radius: 'md',
    shadow: 'glow',
    style: 'linear',
    className: 'rounded-lg bg-indigo-600 font-medium shadow-[0_0_15px_rgba(94,106,210,0.4)]'
  },
  card: {
    radius: 'lg',
    shadow: 'sm',
    bg: '#1c1d22',
    border: true,
    className: 'bg-[#1c1d22]/80 backdrop-blur-md border border-white/[0.08] rounded-xl'
  },
  hero: {
    badgeBg: 'rgba(94, 106, 210, 0.2)',
    badgeText: '#a0aaff',
    align: 'left'
  }
};

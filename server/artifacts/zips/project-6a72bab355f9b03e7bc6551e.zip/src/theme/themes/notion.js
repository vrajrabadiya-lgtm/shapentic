export default {
  name: "notion",
  colors: {
    primary: '#37352f',
    secondary: '#e16259',
    accent: '#d9730d',
    background: '#ffffff',
    surface: '#f7f6f3',
    border: 'rgba(55, 53, 47, 0.16)',
    text: '#37352f',
    textMuted: '#787774'
  },
  button: {
    radius: 'sm',
    shadow: 'sm',
    style: 'notion',
    className: 'rounded font-medium bg-[#37352f] text-white border border-[#37352f]'
  },
  card: {
    radius: 'md',
    shadow: 'sm',
    bg: '#f7f6f3',
    border: true,
    className: 'bg-[#f7f6f3] border border-neutral-300/60 rounded-md shadow-sm'
  },
  hero: {
    badgeBg: 'rgba(225, 98, 89, 0.1)',
    badgeText: '#e16259',
    align: 'left'
  }
};

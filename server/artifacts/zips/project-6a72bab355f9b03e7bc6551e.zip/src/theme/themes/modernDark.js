export default {
  name: "modernDark",
  colors: {
    primary: '#3d5eff',
    secondary: '#00d4ff',
    accent: '#ff007f',
    background: '#0a0a14',
    surface: '#131424',
    border: 'rgba(255, 255, 255, 0.12)',
    text: '#ffffff',
    textMuted: '#94a3b8'
  },
  button: {
    radius: 'xl',
    shadow: 'glow',
    style: 'modernDark',
    className: 'rounded-xl bg-blue-600 text-white shadow-[0_0_20px_rgba(61,94,255,0.4)] font-bold'
  },
  card: {
    radius: 'xl',
    shadow: 'glow',
    bg: '#131424',
    border: true,
    className: 'bg-[#131424]/90 border border-white/10 rounded-2xl backdrop-blur-md'
  },
  hero: {
    badgeBg: 'rgba(61, 94, 255, 0.2)',
    badgeText: '#00d4ff',
    align: 'left'
  }
};

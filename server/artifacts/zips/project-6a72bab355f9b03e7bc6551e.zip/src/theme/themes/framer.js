export default {
  name: "framer",
  colors: {
    primary: '#0099ff',
    secondary: '#ff007f',
    accent: '#7928ca',
    background: '#000000',
    surface: '#121212',
    border: 'rgba(255, 255, 255, 0.15)',
    text: '#ffffff',
    textMuted: '#a0a0a0'
  },
  button: {
    radius: 'full',
    shadow: 'glow',
    style: 'framer',
    className: 'rounded-full bg-cyan-500 hover:bg-cyan-400 font-bold tracking-tight shadow-[0_0_20px_rgba(0,153,255,0.4)]'
  },
  card: {
    radius: '2xl',
    shadow: 'lg',
    bg: '#121212',
    border: true,
    className: 'bg-zinc-900 border border-white/10 rounded-2xl p-6 hover:border-white/30 transition-colors'
  },
  hero: {
    badgeBg: 'rgba(255, 0, 127, 0.2)',
    badgeText: '#ff007f',
    align: 'center'
  }
};

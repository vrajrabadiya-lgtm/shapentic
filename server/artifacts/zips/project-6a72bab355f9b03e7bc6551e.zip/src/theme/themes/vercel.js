export default {
  name: "vercel",
  colors: {
    primary: '#ffffff',
    secondary: '#0070f3',
    accent: '#00d4ff',
    background: '#000000',
    surface: '#111111',
    border: '#333333',
    text: '#ffffff',
    textMuted: '#888888'
  },
  button: {
    radius: 'sm',
    shadow: 'none',
    style: 'vercel',
    className: 'rounded font-semibold text-black bg-white hover:bg-neutral-200'
  },
  card: {
    radius: 'md',
    shadow: 'none',
    bg: '#111111',
    border: true,
    className: 'bg-neutral-900 border border-neutral-800 rounded-md'
  },
  hero: {
    badgeBg: 'rgba(255, 255, 255, 0.1)',
    badgeText: '#ffffff',
    align: 'center'
  }
};

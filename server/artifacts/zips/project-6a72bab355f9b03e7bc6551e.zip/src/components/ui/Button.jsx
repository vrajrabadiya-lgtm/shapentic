import { motion } from 'framer-motion'
import { useTheme } from '../../theme/ThemeProvider'

const sizes = {
  sm: 'text-xs px-4 py-2',
  md: 'text-sm px-6 py-3',
  lg: 'text-base px-8 py-4',
}

export default function Button({
  text = '',
  children,
  variant = 'primary',
  size = 'md',
  onClick,
  href,
  icon,
  loading = false,
  disabled = false,
  fullWidth = false,
  animation = true,
  className = '',
  ...props
}) {
  const { themeTokens } = useTheme();

  const getVariantStyle = () => {
    if (variant === 'primary') {
      return {
        backgroundColor: themeTokens.colors.primary,
        color: '#ffffff',
        boxShadow: themeTokens.shadows[themeTokens.button?.shadow || 'md'],
        border: 'none',
      };
    }
    if (variant === 'secondary') {
      return {
        backgroundColor: themeTokens.colors.surface,
        color: themeTokens.colors.text,
        border: `1px solid ${themeTokens.colors.border}`,
      };
    }
    if (variant === 'outline') {
      return {
        backgroundColor: 'transparent',
        color: themeTokens.colors.primary,
        border: `2px solid ${themeTokens.colors.primary}`,
      };
    }
    return {
      backgroundColor: 'transparent',
      color: themeTokens.colors.text,
      border: 'none',
    };
  };

  const buttonRadius = themeTokens.button?.radius ? (themeTokens.radius[themeTokens.button.radius] || themeTokens.button.radius) : themeTokens.radius.xl;

  const baseClasses = [
    'inline-flex items-center justify-center gap-2 font-bold tracking-wide transition-all duration-200',
    themeTokens.button?.className || '',
    sizes[size] || sizes.md,
    fullWidth ? 'w-full' : '',
    disabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'cursor-pointer',
    className,
  ].filter(Boolean).join(' ')

  const content = (
    <>
      {loading && (
        <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      )}
      {icon && !loading && <span className="text-lg">{icon}</span>}
      {children || text}
    </>
  )

  const motionProps = animation ? {
    whileHover: { scale: disabled ? 1 : 1.03 },
    whileTap: { scale: disabled ? 1 : 0.97 },
    transition: { type: 'spring', stiffness: 400, damping: 17 },
  } : {}

  const mergedStyle = { ...getVariantStyle(), borderRadius: buttonRadius, ...props.style };

  if (href && !disabled) {
    return (
      <motion.a
        href={href}
        className={baseClasses}
        style={mergedStyle}
        {...motionProps}
        {...props}
      >
        {content}
      </motion.a>
    )
  }

  return (
    <motion.button
      className={baseClasses}
      style={mergedStyle}
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      {...motionProps}
      {...props}
    >
      {content}
    </motion.button>
  )
}

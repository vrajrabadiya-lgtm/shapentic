import { motion } from 'framer-motion'
import { useTheme } from '../../theme/ThemeProvider'

export default function StatCard({
  value = '0',
  label = 'Metric',
  icon = '✦',
  description = '',
  color,
  animation = {}
}) {
  const { themeTokens } = useTheme();
  const accent = color || themeTokens.colors.secondary;
  const delay = animation.delay || 0;
  const cardRadius = themeTokens.card?.radius ? (themeTokens.radius[themeTokens.card.radius] || themeTokens.card.radius) : themeTokens.radius.lg;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay }}
      whileHover={{ scale: 1.03, transition: { duration: 0.2 } }}
      className={[
        "p-8 transition-all duration-300 text-center flex flex-col items-center justify-center relative group overflow-hidden border",
        themeTokens.card?.className || "bg-neutral-900 border border-neutral-800 shadow-xl"
      ].filter(Boolean).join(' ')}
      style={{
        backgroundColor: themeTokens.colors.surface,
        borderColor: themeTokens.colors.border,
        borderRadius: cardRadius,
        boxShadow: themeTokens.shadows[themeTokens.card?.shadow || 'lg']
      }}
    >
      <div 
        className="w-12 h-12 rounded-2xl mb-5 flex items-center justify-center text-2xl border shadow-inner group-hover:scale-110 transition-transform duration-300"
        style={{ background: `${accent}15`, borderColor: `${accent}40`, color: accent }}
      >
        {icon}
      </div>
      
      <span 
        className="text-4xl md:text-5xl font-black tracking-tight mb-2 drop-shadow-sm"
        style={{ color: accent }}
      >
        {value}
      </span>
      
      <h3 className="text-base md:text-lg font-bold mb-2" style={{ color: themeTokens.colors.text }}>
        {label}
      </h3>
      
      {description && (
        <p className="text-xs md:text-sm leading-relaxed max-w-xs mx-auto" style={{ color: themeTokens.colors.textMuted }}>
          {description}
        </p>
      )}
    </motion.div>
  )
}

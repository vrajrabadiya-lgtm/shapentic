import React from 'react';
import { motion } from 'framer-motion';
import Button from './Button';
import { useTheme } from '../../theme/ThemeProvider';

export default function PricingCard({
  title = 'Standard',
  price = '$99',
  period = '/mo',
  features = [],
  highlight = false,
  button = 'Select Plan',
  theme = {}
}) {
  const { themeTokens } = useTheme();
  const primary = theme.primary || themeTokens.colors.primary;
  const secondary = theme.secondary || themeTokens.colors.secondary;
  const cardRadius = themeTokens.card?.radius ? (themeTokens.radius[themeTokens.card.radius] || themeTokens.card.radius) : themeTokens.radius.xl;

  return (
    <motion.div
      whileHover={{ y: -6, transition: { duration: 0.2 } }}
      className={`p-8 md:p-10 flex flex-col justify-between transition-all duration-300 relative overflow-hidden border ${
        highlight ? 'shadow-2xl' : 'shadow-xl'
      }`}
      style={{
        backgroundColor: themeTokens.colors.surface,
        borderColor: highlight ? secondary : themeTokens.colors.border,
        borderRadius: cardRadius,
        boxShadow: highlight ? themeTokens.shadows[themeTokens.card?.shadow || 'glow'] : themeTokens.shadows[themeTokens.card?.shadow || 'md'],
      }}
    >
      {highlight && (
        <span 
          className="text-white text-xs px-3.5 py-1 rounded-full uppercase tracking-widest font-extrabold absolute top-4 right-6 shadow-md"
          style={{ background: `linear-gradient(135deg, ${primary}, ${secondary})` }}
        >
          Most Popular
        </span>
      )}
      
      <div>
        <span 
          className="text-xs font-bold uppercase tracking-widest"
          style={{ color: highlight ? secondary : themeTokens.colors.textMuted }}
        >
          {title}
        </span>
        <div className="mt-4 mb-6">
          <span className="text-4xl md:text-5xl font-black" style={{ color: themeTokens.colors.text }}>{price}</span>
          <span className="text-sm md:text-base font-medium" style={{ color: themeTokens.colors.textMuted }}> {period}</span>
        </div>
        
        <ul 
          className="space-y-4 mb-8 text-sm font-medium border-t pt-6 text-left"
          style={{ color: themeTokens.colors.text, borderColor: themeTokens.colors.border }}
        >
          {(features || []).map((f, idx) => (
            <li key={idx} className="flex items-center gap-3">
              <span className="font-bold text-base shrink-0" style={{ color: secondary }}>✓</span> 
              <span>{f}</span>
            </li>
          ))}
        </ul>
      </div>
      
      <div className="w-full">
        <Button 
          variant={highlight ? 'primary' : 'secondary'} 
          size="md" 
          className="w-full justify-center"
        >
          {button}
        </Button>
      </div>
    </motion.div>
  );
}

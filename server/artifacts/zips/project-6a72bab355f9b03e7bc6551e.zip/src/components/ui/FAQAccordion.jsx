import { useState, useId } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useTheme } from '../../theme/ThemeProvider'

export default function FAQAccordion({
  question = '',
  answer = '',
  defaultOpen = false,
  icon = '+',
  theme = {}
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen)
  const id = useId()
  const contentId = `faq-content-${id}`
  const { themeTokens } = useTheme()
  const secondary = theme.secondary || themeTokens.colors.secondary
  const cardRadius = themeTokens.card?.radius ? (themeTokens.radius[themeTokens.card.radius] || themeTokens.card.radius) : themeTokens.radius.md

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="overflow-hidden transition-colors duration-200 border"
      style={{
        backgroundColor: themeTokens.colors.surface,
        borderColor: isOpen ? secondary : themeTokens.colors.border,
        borderRadius: cardRadius
      }}
    >
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-controls={contentId}
        className="w-full p-6 text-left flex justify-between items-center text-base md:text-lg font-bold transition-colors focus:outline-none focus-visible:ring-2"
        style={{ color: isOpen ? secondary : themeTokens.colors.text }}
      >
        <span className="pr-4">{question}</span>
        <span 
          className="w-8 h-8 rounded-full flex items-center justify-center text-base font-extrabold shrink-0 transition-transform duration-300 border"
          style={{ 
            color: secondary, 
            transform: isOpen ? 'rotate(45deg)' : 'rotate(0deg)',
            backgroundColor: 'rgba(255,255,255,0.05)',
            borderColor: themeTokens.colors.border
          }}
        >
          {icon}
        </span>
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            id={contentId}
            role="region"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <div 
              className="px-6 pb-6 pt-2 text-sm md:text-base leading-relaxed border-t"
              style={{ 
                color: themeTokens.colors.textMuted,
                borderColor: themeTokens.colors.border
              }}
            >
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

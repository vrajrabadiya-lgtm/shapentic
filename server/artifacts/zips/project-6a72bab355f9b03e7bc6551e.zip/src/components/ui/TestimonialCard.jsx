import { motion } from 'framer-motion'
import { useTheme } from '../../theme/ThemeProvider'

export default function TestimonialCard({
  name = 'Anonymous',
  role = '',
  company = '',
  avatar,
  rating = 5,
  quote = '',
  theme = {},
  animation = {}
}) {
  const { themeTokens } = useTheme();
  const primary = theme.primary || themeTokens.colors.primary;
  const secondary = theme.secondary || themeTokens.colors.secondary;
  const delay = animation.delay || 0;
  const cardRadius = themeTokens.card?.radius ? (themeTokens.radius[themeTokens.card.radius] || themeTokens.card.radius) : themeTokens.radius.lg;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ y: -6, transition: { duration: 0.2 } }}
      className={[
        "group p-8 transition-all duration-300 shadow-xl relative overflow-hidden flex flex-col justify-between",
        themeTokens.card?.className || "bg-neutral-900/70 border border-white/[0.08] hover:border-[var(--color-secondary,#00d4ff)]/50"
      ].filter(Boolean).join(' ')}
      style={{
        backgroundColor: themeTokens.colors.surface,
        borderColor: themeTokens.colors.border,
        borderRadius: cardRadius,
        boxShadow: themeTokens.shadows[themeTokens.card?.shadow || 'xl']
      }}
    >
      <div 
        className="absolute top-0 left-0 right-0 h-1 opacity-20 group-hover:opacity-100 transition-opacity duration-300"
        style={{ background: `linear-gradient(90deg, ${primary}, ${secondary})` }}
      />

      <div>
        <div className="flex items-center gap-1 mb-6 text-amber-400 text-sm font-bold">
          {Array.from({ length: Math.min(5, Math.max(1, rating)) }).map((_, i) => (
            <span key={i} className="drop-shadow-[0_0_8px_rgba(251,191,36,0.4)]">★</span>
          ))}
        </div>

        <p 
          className="italic text-base md:text-lg leading-relaxed mb-8 font-normal"
          style={{ color: themeTokens.colors.text }}
        >
          &ldquo;{quote}&rdquo;
        </p>
      </div>

      <div className="border-t pt-5 flex items-center gap-4" style={{ borderColor: themeTokens.colors.border }}>
        <div 
          className="w-12 h-12 rounded-2xl border flex items-center justify-center font-extrabold text-white text-base shadow-inner shrink-0"
          style={{ 
            background: `linear-gradient(135deg, ${primary}33, ${secondary}33)`,
            borderColor: `${secondary}66`
          }}
        >
          {avatar ? (
            <img src={avatar} alt={name} className="w-full h-full rounded-2xl object-cover" />
          ) : (
            (name || 'A')[0].toUpperCase()
          )}
        </div>
        <div>
          <h4 className="font-bold text-base tracking-tight" style={{ color: themeTokens.colors.text }}>{name}</h4>
          {(role || company) && (
            <span className="text-xs font-semibold" style={{ color: themeTokens.colors.textMuted }}>
              {role}{role && company ? ' · ' : ''}{company}
            </span>
          )}
        </div>
      </div>
    </motion.div>
  )
}

import { motion } from 'framer-motion'
import { useTheme } from '../../theme/ThemeProvider'

export default function FeatureCard({
  icon = '⚡',
  title = 'Feature',
  description = '',
  accentColor,
  animation = {},
  hoverEffect = true,
}) {
  const { themeTokens } = useTheme();
  const accent = accentColor || themeTokens.colors.primary;
  const delay = animation.delay || 0;
  const cardRadius = themeTokens.card?.radius ? (themeTokens.radius[themeTokens.card.radius] || themeTokens.card.radius) : themeTokens.radius.lg;

  return (
    <motion.div
      className={[
        'group p-8 transition-all duration-300 flex items-start gap-6',
        themeTokens.card?.className || 'bg-neutral-900 border border-neutral-800 shadow-xl',
        hoverEffect ? 'hover:shadow-2xl hover:brightness-110' : '',
      ].filter(Boolean).join(' ')}
      style={{
        backgroundColor: themeTokens.colors.surface,
        borderColor: themeTokens.colors.border,
        borderRadius: cardRadius,
        boxShadow: themeTokens.shadows[themeTokens.card?.shadow || 'md'],
      }}
      initial={themeTokens.animations.fadeUp?.initial || { opacity: 0, y: 24 }}
      whileInView={themeTokens.animations.fadeUp?.whileInView || { opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.5, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
    >
      <div
        className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shrink-0 border transition-colors duration-300"
        style={{
          background: accent + '15',
          borderColor: accent + '40',
        }}
      >
        {icon}
      </div>
      <div>
        <h3 
          className="text-xl font-bold mb-2 tracking-tight"
          style={{ color: themeTokens.colors.text }}
        >
          {title}
        </h3>
        <p 
          className="text-sm leading-relaxed"
          style={{ color: themeTokens.colors.textMuted }}
        >
          {description}
        </p>
      </div>
    </motion.div>
  )
}

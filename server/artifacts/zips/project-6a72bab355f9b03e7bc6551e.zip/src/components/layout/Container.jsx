import React from 'react';
import { useTheme } from '../../theme/ThemeProvider';

export default function Container({ size = 'xl', className = '', children }) {
  const { themeTokens } = useTheme();
  const sizes = {
    sm: 'max-w-3xl',
    md: 'max-w-5xl',
    lg: 'max-w-6xl',
    xl: 'max-w-7xl',
    full: 'max-w-full'
  };
  const maxW = sizes[size] || sizes.xl;
  return (
    <div className={`mx-auto px-6 w-full ${maxW} ${className}`}>
      {children}
    </div>
  );
}

import React from 'react';
import { useTheme } from '../../theme/ThemeProvider';

export default function Section({ spacing = 'lg', background = 'default', divider = false, className = '', id, children }) {
  const { themeTokens } = useTheme();
  const spaces = {
    none: '0px',
    sm: themeTokens.spacing.xl || '2rem',
    md: themeTokens.spacing['2xl'] || '3rem',
    lg: themeTokens.spacing['3xl'] || '5rem',
    xl: '7rem'
  };
  const bgs = {
    default: 'transparent',
    surface: themeTokens.colors.surface,
    dark: themeTokens.colors.background,
    gradient: `linear-gradient(to bottom, ${themeTokens.colors.background}, ${themeTokens.colors.surface})`
  };
  const py = spaces[spacing] || spaces.lg;
  const bg = bgs[background] || background;

  return (
    <section 
      id={id} 
      className={`relative w-full ${divider ? 'border-t' : ''} ${className}`}
      style={{
        paddingTop: py,
        paddingBottom: py,
        background: bg,
        borderColor: divider ? themeTokens.colors.border : 'transparent'
      }}
    >
      {children}
    </section>
  );
}

import React from 'react';
import { useTheme } from '../../theme/ThemeProvider';

export default function Stack({ spacing = 'md', align = 'stretch', className = '', children }) {
  const { themeTokens } = useTheme();
  const aligns = {
    stretch: 'items-stretch',
    start: 'items-start',
    center: 'items-center',
    end: 'items-end'
  };
  const alignClass = aligns[align] || aligns.stretch;
  const gapValue = themeTokens.spacing[spacing] || themeTokens.spacing.md || '1rem';

  return (
    <div 
      className={`flex flex-col ${alignClass} ${className}`}
      style={{ gap: gapValue }}
    >
      {children}
    </div>
  );
}

import { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { motion } from 'framer-motion'
import Button from '../ui/Button'
import { useTheme } from '../../theme/ThemeProvider'

function FormatTitle({ text }) {
  if (!text) return null
  const parts = String(text).split(/\\n|\n/)
  return parts.map((part, i) => (
    <span key={i}>
      {i > 0 && <br />}
      {part}
    </span>
  ))
}

export default function HeroLayout({
  title = '',
  subtitle = '',
  description = '',
  badge = '',
  buttons = [],
  background,
  alignment = 'left',
  theme = {},
  scene = null,
}) {
  const { themeTokens } = useTheme();
  const align = themeTokens.hero?.align || alignment;
  const isCenter = align === 'center' || alignment === 'center';
  const hasScene = !!scene;
  
  const primary = theme.primary || themeTokens.colors.primary;
  const secondary = theme.secondary || themeTokens.colors.secondary;
  const textColor = theme.text || themeTokens.colors.text;
  const bg = background || themeTokens.colors.background;
  const badgeBg = themeTokens.hero?.badgeBg || (primary + '20');
  const badgeText = themeTokens.hero?.badgeText || secondary;

  return (
    <section
      className={`relative min-h-screen overflow-hidden ${hasScene && !isCenter ? 'grid lg:grid-cols-2' : 'flex flex-col'}`}
      style={{ background: bg }}
    >
      {/* ── Content Column ───────────────────────────────────── */}
      <div className={`flex flex-col justify-center z-10 px-8 lg:px-20 py-32 ${isCenter ? 'items-center text-center mx-auto max-w-4xl' : ''}`}>

        {badge && (
          <motion.div
            className="mb-6 inline-flex items-center gap-2 self-start px-4 py-1.5 rounded-full text-sm font-medium"
            style={{
              background: badgeBg,
              border: '1px solid ' + primary + '44',
              color: badgeText,
              ...(isCenter ? { alignSelf: 'center' } : {}),
            }}
            initial={{ opacity: 0, x: isCenter ? 0 : -20, y: isCenter ? -10 : 0 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: badgeText }} />
            {badge}
          </motion.div>
        )}

        <motion.h1
          className="font-bold leading-[1.05] mb-6"
          style={{ fontSize: 'clamp(2.5rem, 5vw, 4.5rem)', color: textColor }}
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        >
          <FormatTitle text={title} />
        </motion.h1>

        {subtitle && (
          <motion.p
            className="text-lg lg:text-xl font-medium mb-3 max-w-xl"
            style={{ color: textColor + 'dd' }}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            {subtitle}
          </motion.p>
        )}

        {description && (
          <motion.p
            className="text-sm lg:text-base mb-10 max-w-xl leading-relaxed"
            style={{ color: themeTokens.colors.textMuted }}
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.28 }}
          >
            {description}
          </motion.p>
        )}

        {buttons.length > 0 && (
          <motion.div
            className={`flex flex-wrap gap-4 ${isCenter ? 'justify-center' : ''}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.35 }}
          >
            {buttons.map((btn, idx) => (
              <Button key={idx} {...btn} size={btn.size || 'lg'} />
            ))}
          </motion.div>
        )}
      </div>

      {/* ── 3D Scene Column ──────────────────────────────────── */}
      {hasScene && (
        <div className={`${isCenter ? 'absolute inset-0 opacity-40' : 'hidden lg:block relative'}`}>
          <div className="absolute inset-0">
            <Canvas camera={{ position: [0, 0, 5], fov: 60 }} dpr={[1, 2]}>
              <Suspense fallback={null}>
                {scene}
              </Suspense>
            </Canvas>
          </div>
        </div>
      )}

      {/* Bottom gradient fade */}
      <div
        className="absolute bottom-0 inset-x-0 h-28 pointer-events-none z-10"
        style={{ background: 'linear-gradient(to top, ' + bg + ', transparent)' }}
      />
    </section>
  )
}

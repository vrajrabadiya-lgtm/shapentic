import React from 'react';
import { useTheme } from '../../theme/ThemeProvider';

export default function Grid({ columns = 3, gap = 'md', align = 'stretch', className = '', children }) {
  const { themeTokens } = useTheme();
  const cols = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 md:grid-cols-2',
    3: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4'
  };
  const aligns = {
    stretch: 'items-stretch',
    start: 'items-start',
    center: 'items-center',
    end: 'items-end'
  };
  const colClass = cols[columns] || cols[3];
  const alignClass = aligns[align] || aligns.stretch;
  const gapValue = themeTokens.spacing[gap] || themeTokens.spacing.lg || '2rem';

  return (
    <div 
      className={`grid ${colClass} ${alignClass} ${className}`}
      style={{ gap: gapValue }}
    >
      {children}
    </div>
  );
}

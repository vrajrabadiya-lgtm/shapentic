import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'

const FEATURES = []

export default function FeaturesSection() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="py-28" style={{ background: '#0a0a14' }}>
      <div className="max-w-7xl mx-auto px-8">
        <motion.div
          className="text-center max-w-2xl mx-auto mb-16"
          initial={{ opacity: 0, y: 25 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.65 }}
        >
          <h2
            className="font-bold mb-4"
            style={{ fontSize: 'clamp(2rem, 3.5vw, 3.5rem)', color: '#f0f0ff' }}
          >
            What We Offer
          </h2>
          <p style={{ color: '#f0f0ff65' }}></p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES.map((feature, i) => (
            <motion.div
              key={i}
              className="p-7 rounded-2xl"
              style={{
                background: '#f0f0ff06',
                border: '1px solid #f0f0ff0f',
              }}
              initial={{ opacity: 0, y: 28 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              whileHover={{ y: -3, transition: { duration: 0.18 } }}
            >
              <div
                className="w-11 h-11 rounded-xl flex items-center justify-center text-xl mb-5"
                style={{ background: '#3d5eff18' }}
              >
                {feature.icon}
              </div>
              <h3
                className="text-base font-semibold mb-2"
                style={{ color: '#f0f0ff' }}
              >
                {feature.title}
              </h3>
              <p className="text-sm leading-relaxed" style={{ color: '#f0f0ff65' }}>
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
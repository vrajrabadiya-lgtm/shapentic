import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function SkillsSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#061a40' }}>
              Skills
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Technical Skills</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"Backend Development","desc":"Expertise in building scalable backend systems.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"C++","desc":"Proficient in C++ for system-level programming.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Distributed Systems","desc":"Experience with distributed systems and microservices.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Node.js","desc":"Skilled in Node.js for building fast, scalable network applications.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Express.js","desc":"Experience with Express.js for web applications.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"MongoDB","desc":"Proficient in MongoDB for NoSQL database management.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Redis","desc":"Experience with Redis for in-memory data structure store.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"BullMQ","desc":"Skilled in BullMQ for managing job queues.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"REST APIs","desc":"Experience in designing and implementing RESTful APIs.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"React","desc":"Proficient in React for building user interfaces.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Docker","desc":"Experience with Docker for containerization.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Git","desc":"Proficient in Git for version control.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Data Structures & Algorithms","desc":"Strong understanding of data structures and algorithms.","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import Grid from '../layout/Grid';

export default function ResumeSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#061a40' }}>
              Resume
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Resume</h2>
            {"Download my resume to learn more about my experience and skills." && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto">Download my resume to learn more about my experience and skills.</p>
            )}
          </div>
          
          <Grid columns={1} gap="md">
            {[].map((it, idx) => (
              <div key={idx} className="p-8 rounded-3xl bg-slate-900/60 border border-slate-800 hover:border-indigo-500/40 transition-all shadow-xl flex items-start gap-6">
                <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/30 flex items-center justify-center text-2xl shrink-0">{it.icon || '✦'}</div>
                <div>
                  <h3 className="text-2xl font-bold text-white mb-3">{it.title}</h3>
                  <p className="text-slate-400 leading-relaxed text-sm">{it.desc}</p>
                </div>
              </div>
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

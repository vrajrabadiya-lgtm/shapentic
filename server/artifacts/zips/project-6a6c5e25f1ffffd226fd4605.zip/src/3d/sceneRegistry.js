// Standardized 3D Scene Registry for client runtime
export const SCENE_REGISTRY = {
  "FloatingBlobScene": {
    "id": "FloatingBlobScene",
    "name": "Floating Morphing Blob",
    "supportedIndustries": [
      "Technology",
      "SaaS",
      "Creative",
      "Startup"
    ],
    "complexity": "Medium",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Apple",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Morph",
      "Idle Float"
    ],
    "supportedThemes": [
      "apple",
      "vercel",
      "linear",
      "modernDark"
    ]
  },
  "GlassOrbScene": {
    "id": "GlassOrbScene",
    "name": "Refractive Glass Orb",
    "supportedIndustries": [
      "FinTech",
      "Technology",
      "Agency",
      "Luxury"
    ],
    "complexity": "High",
    "cameraPreset": "Close-up",
    "lightingPreset": "Glass",
    "performanceCost": "High",
    "defaultAnimations": [
      "Idle Float",
      "Hover Rotation"
    ],
    "supportedThemes": [
      "apple",
      "stripe",
      "notion",
      "minimal"
    ]
  },
  "ParticleGalaxyScene": {
    "id": "ParticleGalaxyScene",
    "name": "Cosmic Particle Galaxy",
    "supportedIndustries": [
      "Technology",
      "Space",
      "Gaming",
      "AI"
    ],
    "complexity": "High",
    "cameraPreset": "Wide",
    "lightingPreset": "Dark Tech",
    "performanceCost": "High",
    "defaultAnimations": [
      "Scroll Rotation",
      "Mouse Follow"
    ],
    "supportedThemes": [
      "linear",
      "modernDark",
      "vercel"
    ]
  },
  "EnergyCoreScene": {
    "id": "EnergyCoreScene",
    "name": "Pulsating Energy Core",
    "supportedIndustries": [
      "Gaming",
      "Technology",
      "SaaS",
      "Engineering"
    ],
    "complexity": "Medium",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Neon",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Pulse",
      "Idle Float"
    ],
    "supportedThemes": [
      "modernDark",
      "vercel",
      "linear"
    ]
  },
  "OrbitRingScene": {
    "id": "OrbitRingScene",
    "name": "Multi-Axis Orbital Rings",
    "supportedIndustries": [
      "FinTech",
      "SaaS",
      "Education",
      "Corporate"
    ],
    "complexity": "Low",
    "cameraPreset": "Orbit Camera",
    "lightingPreset": "Studio",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Hover Rotation",
      "Parallax"
    ],
    "supportedThemes": [
      "stripe",
      "apple",
      "notion",
      "linear"
    ]
  },
  "GradientCloudScene": {
    "id": "GradientCloudScene",
    "name": "Volumetric Ambient Cloud",
    "supportedIndustries": [
      "Healthcare",
      "Wellness",
      "Travel",
      "Beauty"
    ],
    "complexity": "Medium",
    "cameraPreset": "Wide",
    "lightingPreset": "Sunset",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Idle Float",
      "Reveal"
    ],
    "supportedThemes": [
      "framer",
      "apple",
      "minimal",
      "notion"
    ]
  },
  "WireframeWorldScene": {
    "id": "WireframeWorldScene",
    "name": "Wireframe Planetary Grid",
    "supportedIndustries": [
      "Space",
      "Technology",
      "E-Commerce",
      "Global"
    ],
    "complexity": "Low",
    "cameraPreset": "Orbit Camera",
    "lightingPreset": "Dark Tech",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Scroll Rotation",
      "Idle Float"
    ],
    "supportedThemes": [
      "linear",
      "modernDark",
      "vercel"
    ]
  },
  "FloatingCardsScene": {
    "id": "FloatingCardsScene",
    "name": "Layered 3D UI Cards",
    "supportedIndustries": [
      "Agency",
      "SaaS",
      "Portfolio",
      "Design"
    ],
    "complexity": "Medium",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Apple",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Parallax",
      "Mouse Follow"
    ],
    "supportedThemes": [
      "apple",
      "vercel",
      "notion",
      "linear"
    ]
  },
  "DashboardScene": {
    "id": "DashboardScene",
    "name": "3D Analytics Dashboard",
    "supportedIndustries": [
      "SaaS",
      "FinTech",
      "Corporate",
      "B2B"
    ],
    "complexity": "Medium",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Studio",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Hover Rotation",
      "Reveal"
    ],
    "supportedThemes": [
      "apple",
      "stripe",
      "linear",
      "vercel"
    ]
  },
  "ProductPedestalScene": {
    "id": "ProductPedestalScene",
    "name": "Luxury Product Pedestal",
    "supportedIndustries": [
      "E-Commerce",
      "Fashion",
      "Automobile",
      "Luxury",
      "Retail"
    ],
    "complexity": "Medium",
    "cameraPreset": "Product Camera",
    "lightingPreset": "Studio",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Hover Rotation",
      "Idle Float"
    ],
    "supportedThemes": [
      "minimal",
      "apple",
      "notion"
    ]
  },
  "ConstellationScene": {
    "id": "ConstellationScene",
    "name": "Interactive Star Constellation",
    "supportedIndustries": [
      "Portfolio",
      "Education",
      "Agency",
      "Science"
    ],
    "complexity": "Medium",
    "cameraPreset": "Wide",
    "lightingPreset": "Cinematic",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Mouse Follow",
      "Pulse"
    ],
    "supportedThemes": [
      "linear",
      "modernDark",
      "framer"
    ]
  },
  "LightBeamScene": {
    "id": "LightBeamScene",
    "name": "Volumetric Neon Prism Ray",
    "supportedIndustries": [
      "Technology",
      "Creative",
      "Studio",
      "Music"
    ],
    "complexity": "High",
    "cameraPreset": "Close-up",
    "lightingPreset": "Neon",
    "performanceCost": "High",
    "defaultAnimations": [
      "Reveal",
      "Pulse"
    ],
    "supportedThemes": [
      "modernDark",
      "vercel",
      "linear"
    ]
  },
  "GridFloorScene": {
    "id": "GridFloorScene",
    "name": "Futuristic Synthwave Grid",
    "supportedIndustries": [
      "Gaming",
      "Automobile",
      "Dark Tech",
      "Cyberpunk"
    ],
    "complexity": "Low",
    "cameraPreset": "Scroll Camera",
    "lightingPreset": "Neon",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Parallax",
      "Scroll Rotation"
    ],
    "supportedThemes": [
      "modernDark",
      "linear"
    ]
  },
  "LiquidSphereScene": {
    "id": "LiquidSphereScene",
    "name": "Dynamic Fluid Liquid Sphere",
    "supportedIndustries": [
      "Fashion",
      "Beauty",
      "Luxury",
      "Art"
    ],
    "complexity": "High",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Glass",
    "performanceCost": "High",
    "defaultAnimations": [
      "Morph",
      "Mouse Follow"
    ],
    "supportedThemes": [
      "minimal",
      "apple",
      "notion"
    ]
  },
  "GlassCubeScene": {
    "id": "GlassCubeScene",
    "name": "Refractive Crystalline Cube Matrix",
    "supportedIndustries": [
      "Architecture",
      "Real Estate",
      "Law Firm",
      "Consultancy"
    ],
    "complexity": "Medium",
    "cameraPreset": "Orbit Camera",
    "lightingPreset": "Glass",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Hover Rotation",
      "Idle Float"
    ],
    "supportedThemes": [
      "notion",
      "stripe",
      "minimal",
      "apple"
    ]
  },
  "FloatingIconsScene": {
    "id": "FloatingIconsScene",
    "name": "Floating Symbol Ecosystem",
    "supportedIndustries": [
      "SaaS",
      "Education",
      "Agency",
      "Marketing"
    ],
    "complexity": "Low",
    "cameraPreset": "Wide",
    "lightingPreset": "Apple",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Idle Float",
      "Parallax"
    ],
    "supportedThemes": [
      "apple",
      "vercel",
      "notion"
    ]
  },
  "HologramScene": {
    "id": "HologramScene",
    "name": "Sci-Fi Holographic Projection",
    "supportedIndustries": [
      "Technology",
      "Automobile",
      "Engineering",
      "Industrial"
    ],
    "complexity": "Medium",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Dark Tech",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Hover Rotation",
      "Pulse"
    ],
    "supportedThemes": [
      "linear",
      "modernDark",
      "vercel"
    ]
  },
  "NeonTunnelScene": {
    "id": "NeonTunnelScene",
    "name": "High-Velocity Infinite Tunnel Loop",
    "supportedIndustries": [
      "Gaming",
      "Entertainment",
      "Creative",
      "Sports"
    ],
    "complexity": "Medium",
    "cameraPreset": "Scroll Camera",
    "lightingPreset": "Neon",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Scroll Rotation",
      "Reveal"
    ],
    "supportedThemes": [
      "modernDark",
      "linear"
    ]
  },
  "DeviceMockupScene": {
    "id": "DeviceMockupScene",
    "name": "Cinematic Laptop / Smartphone Mockup",
    "supportedIndustries": [
      "SaaS",
      "Portfolio",
      "Mobile App",
      "Tech"
    ],
    "complexity": "Medium",
    "cameraPreset": "Product Camera",
    "lightingPreset": "Apple",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Hover Rotation",
      "Mouse Follow"
    ],
    "supportedThemes": [
      "apple",
      "vercel",
      "linear"
    ]
  },
  "InteractivePlanetScene": {
    "id": "InteractivePlanetScene",
    "name": "Interactive Atmosphere Globe",
    "supportedIndustries": [
      "Portfolio",
      "Travel",
      "Space",
      "Global"
    ],
    "complexity": "High",
    "cameraPreset": "Orbit Camera",
    "lightingPreset": "Cinematic",
    "performanceCost": "High",
    "defaultAnimations": [
      "Hover Rotation",
      "Mouse Follow",
      "Idle Float"
    ],
    "supportedThemes": [
      "linear",
      "modernDark",
      "apple",
      "vercel"
    ]
  },
  "FloatingFoodScene": {
    "id": "FloatingFoodScene",
    "name": "Gourmet Plating & Culinary Elements",
    "supportedIndustries": [
      "Restaurant",
      "Dining",
      "Food",
      "Cafe"
    ],
    "complexity": "Medium",
    "cameraPreset": "Close-up",
    "lightingPreset": "Studio",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Idle Float",
      "Hover Rotation"
    ],
    "supportedThemes": [
      "notion",
      "apple",
      "minimal"
    ]
  },
  "RotatingPlateScene": {
    "id": "RotatingPlateScene",
    "name": "360 Rotating Gourmet Tableware",
    "supportedIndustries": [
      "Restaurant",
      "Luxury",
      "Dining"
    ],
    "complexity": "Medium",
    "cameraPreset": "Product Camera",
    "lightingPreset": "Studio",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Hover Rotation",
      "Idle Float"
    ],
    "supportedThemes": [
      "notion",
      "minimal"
    ]
  },
  "SteamScene": {
    "id": "SteamScene",
    "name": "Delicate Rising Vapor Field",
    "supportedIndustries": [
      "Restaurant",
      "Cafe",
      "Wellness"
    ],
    "complexity": "Medium",
    "cameraPreset": "Close-up",
    "lightingPreset": "Sunset",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Reveal",
      "Idle Float"
    ],
    "supportedThemes": [
      "notion",
      "minimal",
      "framer"
    ]
  },
  "FloatingIngredientsScene": {
    "id": "FloatingIngredientsScene",
    "name": "Artisanal Herbs & Culinary Ingredients",
    "supportedIndustries": [
      "Restaurant",
      "Food",
      "Bistro"
    ],
    "complexity": "Low",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Apple",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Parallax",
      "Idle Float"
    ],
    "supportedThemes": [
      "notion",
      "apple"
    ]
  },
  "DNAHelixScene": {
    "id": "DNAHelixScene",
    "name": "Cinematic Double-Helix Strand",
    "supportedIndustries": [
      "Healthcare",
      "Medical",
      "Biotech",
      "Science"
    ],
    "complexity": "Medium",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Glass",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Idle Float",
      "Hover Rotation"
    ],
    "supportedThemes": [
      "framer",
      "apple",
      "linear"
    ]
  },
  "MedicalMoleculesScene": {
    "id": "MedicalMoleculesScene",
    "name": "Precision Molecular Matrix",
    "supportedIndustries": [
      "Healthcare",
      "Science",
      "Pharma"
    ],
    "complexity": "Low",
    "cameraPreset": "Orbit Camera",
    "lightingPreset": "Studio",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Hover Rotation",
      "Mouse Follow"
    ],
    "supportedThemes": [
      "framer",
      "minimal",
      "apple"
    ]
  },
  "HeartbeatScene": {
    "id": "HeartbeatScene",
    "name": "Rhythmic Waveform Frequency Pulse",
    "supportedIndustries": [
      "Healthcare",
      "Fitness",
      "Wellness"
    ],
    "complexity": "Low",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Neon",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Pulse",
      "Idle Float"
    ],
    "supportedThemes": [
      "framer",
      "modernDark",
      "linear"
    ]
  },
  "VehicleShowcaseScene": {
    "id": "VehicleShowcaseScene",
    "name": "Aerodynamic Automotive Profile",
    "supportedIndustries": [
      "Automobile",
      "Engineering",
      "Luxury"
    ],
    "complexity": "High",
    "cameraPreset": "Product Camera",
    "lightingPreset": "Cinematic",
    "performanceCost": "High",
    "defaultAnimations": [
      "Hover Rotation",
      "Reveal"
    ],
    "supportedThemes": [
      "linear",
      "modernDark",
      "stripe"
    ]
  },
  "TurntableScene": {
    "id": "TurntableScene",
    "name": "Reflective Revolving Stage Showcase",
    "supportedIndustries": [
      "Automobile",
      "Product",
      "E-Commerce"
    ],
    "complexity": "Medium",
    "cameraPreset": "Orbit Camera",
    "lightingPreset": "Studio",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Hover Rotation",
      "Idle Float"
    ],
    "supportedThemes": [
      "linear",
      "stripe",
      "apple"
    ]
  },
  "ReflectionFloorScene": {
    "id": "ReflectionFloorScene",
    "name": "Glossy Specular Ground Studio",
    "supportedIndustries": [
      "Automobile",
      "Luxury",
      "Fashion"
    ],
    "complexity": "Medium",
    "cameraPreset": "Wide",
    "lightingPreset": "Dark Tech",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Parallax",
      "Scroll Rotation"
    ],
    "supportedThemes": [
      "modernDark",
      "minimal",
      "linear"
    ]
  },
  "FloatingSkillsScene": {
    "id": "FloatingSkillsScene",
    "name": "Developer Proficiency Node Tags",
    "supportedIndustries": [
      "Portfolio",
      "Developer",
      "Freelance"
    ],
    "complexity": "Low",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Vercel",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Parallax",
      "Mouse Follow"
    ],
    "supportedThemes": [
      "linear",
      "vercel",
      "apple"
    ]
  },
  "FloatingFabricScene": {
    "id": "FloatingFabricScene",
    "name": "Silken Simulated Drapery Ribbon",
    "supportedIndustries": [
      "Fashion",
      "Luxury",
      "Boutique",
      "Apparel"
    ],
    "complexity": "High",
    "cameraPreset": "Hero Camera",
    "lightingPreset": "Sunset",
    "performanceCost": "High",
    "defaultAnimations": [
      "Morph",
      "Idle Float"
    ],
    "supportedThemes": [
      "apple",
      "minimal",
      "notion"
    ]
  },
  "LuxuryLightingScene": {
    "id": "LuxuryLightingScene",
    "name": "Architectural Spotlight Illumination",
    "supportedIndustries": [
      "Fashion",
      "Jewelry",
      "Fine Art",
      "Studio"
    ],
    "complexity": "Medium",
    "cameraPreset": "Close-up",
    "lightingPreset": "Studio",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Reveal",
      "Hover Rotation"
    ],
    "supportedThemes": [
      "minimal",
      "apple",
      "notion"
    ]
  },
  "GlassObjectsScene": {
    "id": "GlassObjectsScene",
    "name": "Abstract Geometric Prism Sculpture",
    "supportedIndustries": [
      "Agency",
      "Studio",
      "Design",
      "Architecture"
    ],
    "complexity": "Medium",
    "cameraPreset": "Orbit Camera",
    "lightingPreset": "Glass",
    "performanceCost": "Medium",
    "defaultAnimations": [
      "Hover Rotation",
      "Parallax"
    ],
    "supportedThemes": [
      "vercel",
      "apple",
      "notion",
      "linear"
    ]
  },
  "AnimatedTimelineScene": {
    "id": "AnimatedTimelineScene",
    "name": "Branching Evolutionary Milestones",
    "supportedIndustries": [
      "Agency",
      "SaaS",
      "Corporate",
      "History"
    ],
    "complexity": "Low",
    "cameraPreset": "Scroll Camera",
    "lightingPreset": "Apple",
    "performanceCost": "Low",
    "defaultAnimations": [
      "Scroll Rotation",
      "Reveal"
    ],
    "supportedThemes": [
      "vercel",
      "apple",
      "stripe"
    ]
  }
};

export function getSceneMeta(id) {
  return SCENE_REGISTRY[id] || SCENE_REGISTRY.FloatingBlobScene;
}

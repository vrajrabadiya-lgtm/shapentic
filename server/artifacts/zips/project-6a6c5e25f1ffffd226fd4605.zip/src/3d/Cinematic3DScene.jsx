import React from 'react'
import { SceneContent } from './SceneComposer'

export default function Cinematic3DScene({ sceneId, style = {} }) {
  return (
    <SceneContent
      sceneId={sceneId || "undefined"}
      cameraPreset="undefined"
      lightingPreset="undefined"
      interactionPreset="undefined"
      quality="undefined"
    />
  )
}
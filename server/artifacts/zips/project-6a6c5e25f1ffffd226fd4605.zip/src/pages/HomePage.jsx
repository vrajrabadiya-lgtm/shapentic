import React from 'react';
import HeroSection from '../components/sections/HeroSection';
import TeamCapabilitiesSection from '../components/sections/TeamCapabilitiesSection';
import DriverTestimonialsSection from '../components/sections/DriverTestimonialsSection';
import SponsorshipPackagesSection from '../components/sections/SponsorshipPackagesSection';
import FAQSection from '../components/sections/FAQSection';
import SampleSection from '../components/sections/SampleSection';
import CTASection from '../components/sections/CTASection';

export default function HomePage() {
  return (
    <div className="page-home">
      <HeroSection />
      <TeamCapabilitiesSection />
      <DriverTestimonialsSection />
      <SponsorshipPackagesSection />
      <FAQSection />
      <SampleSection />
      <CTASection />
    </div>
  );
}

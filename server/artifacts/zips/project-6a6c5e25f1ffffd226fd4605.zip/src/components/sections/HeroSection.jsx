import React from 'react'
import HeroLayout from '../layout/HeroLayout'
import Cinematic3DScene from '../../3d/Cinematic3DScene'

const heroData = {
  "title": "Apex F1 Racing",
  "subtitle": "The pinnacle of speed and innovation in Formula One.",
  "description": "The pinnacle of speed and innovation in Formula One.",
  "badge": "Cyberpunk Racing Excellence",
  "alignment": "left",
  "background": "#0a0a14",
  "theme": {
    "primary": "#3d5eff",
    "secondary": "#00d4ff",
    "text": "#f0f0ff"
  },
  "buttons": [
    {
      "text": "Explore Apex F1 Racing",
      "variant": "primary"
    }
  ]
}

export default function HeroSection() {
  return (
    <HeroLayout
      {...heroData}
      scene={<Cinematic3DScene />}
    />
  )
}

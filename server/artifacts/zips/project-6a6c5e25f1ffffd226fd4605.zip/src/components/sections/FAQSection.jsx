import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FAQAccordion from '../ui/FAQAccordion';

export default function FAQSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#ff5733' }}>
              FAQ
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Frequently Asked Questions</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <div className="max-w-3xl mx-auto w-full">
            <FAQAccordion items={[{"q":"What makes Apex F1 Racing unique?","a":"Our unique blend of cutting-edge technology, world-class talent, and a cyberpunk aesthetic sets us apart in the world of Formula One."}]} />
          </div>
        </Stack>
      </Container>
    </Section>
  );
}

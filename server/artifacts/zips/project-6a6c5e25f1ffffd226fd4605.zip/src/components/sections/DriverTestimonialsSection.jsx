import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import TestimonialCard from '../ui/TestimonialCard';
import Grid from '../layout/Grid';

export default function DriverTestimonialsSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#ff5733' }}>
              Driver Testimonials
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Voices from the Track</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={3} gap="md">
            {[{"quote":"Driving for Apex F1 Racing is a dream come true. The team's dedication and innovation are unmatched.","author":"Max Verstappen","role":"Lead Driver","company":""},{"quote":"Apex F1 Racing has given me the tools to compete at the highest level. Their support is incredible.","author":"Lewis Hamilton","role":"Senior Driver","company":""}].map((t, idx) => (
              <TestimonialCard key={idx} {...t} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

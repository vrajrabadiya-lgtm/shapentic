import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function TeamCapabilitiesSection() {
  return (
    <Section spacing="lg" className="layout-default animate-slide-up">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#ff5733' }}>
              Team Capabilities
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Unrivaled Expertise</h2>
            {"Our team combines unparalleled skill and cutting-edge technology." && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto">Our team combines unparalleled skill and cutting-edge technology.</p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"World-class Engineers","desc":"Our engineers are the best in the industry, constantly pushing the boundaries of what's possible.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"High-Performance Analytics","desc":"We use advanced analytics to optimize every aspect of our cars and strategy.","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

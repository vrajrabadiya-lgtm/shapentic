import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import PricingCard from '../ui/PricingCard';
import Grid from '../layout/Grid';

export default function SponsorshipPackagesSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#ff5733' }}>
              Sponsorship Packages
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Join Us on the Track</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={3} gap="md" align="stretch">
            {[{"title":"Bronze","price":"$50,000","period":"Annual","features":[],"highlight":false,"button":"Select Package"},{"title":"Silver","price":"$150,000","period":"Annual","features":[],"highlight":false,"button":"Select Package"},{"title":"Gold","price":"$500,000","period":"Annual","features":[],"highlight":false,"button":"Select Package"}].map((tier, idx) => (
              <PricingCard key={idx} {...tier} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

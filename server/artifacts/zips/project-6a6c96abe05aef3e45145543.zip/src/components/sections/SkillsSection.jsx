import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function SkillsSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#667eea' }}>
              Skills
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Skills</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"Languages","desc":"C++, Python","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Backend","desc":"Node.js, Express.js, REST APIs","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Databases","desc":"MongoDB, MySQL","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Systems","desc":"OS, CN, OOP, DBMS","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Tools","desc":"Git, GitHub, Docker, Postman","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Frontend","desc":"React.js, HTML, CSS","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"AI/ML","desc":"Deep Learning, NLP","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

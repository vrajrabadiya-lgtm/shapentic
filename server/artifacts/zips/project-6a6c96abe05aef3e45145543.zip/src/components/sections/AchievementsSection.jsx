import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function AchievementsSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#667eea' }}>
              Achievements
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Achievements</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"DSA Problems Solved","desc":"300+ problems solved","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Mentoring","desc":"Mentored 50+ students","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Leadership","desc":"Secretary of TechHub, Organized Hack-Nocturne 2.0","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

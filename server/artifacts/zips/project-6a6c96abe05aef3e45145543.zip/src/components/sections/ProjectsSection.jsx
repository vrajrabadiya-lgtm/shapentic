import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function ProjectsSection() {
  return (
    <Section spacing="lg" className="layout-grid animate-slide-up">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#007bff' }}>
              Featured Projects
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Featured Projects</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"AetherWeb","desc":"High-concurrency multithreaded web server with 3350+ requests/sec.","icon":"🚀","price":"","period":"","author":"","role":"","quote":""},{"title":"AegisDB","desc":"Embedded LSM-Tree database with Write-Ahead Logging, Bloom Filters, MemTables, SSTables, and 88,397 ops/sec.","icon":"💾","price":"","period":"","author":"","role":"","quote":""},{"title":"CoType","desc":"Real-time collaborative editor using WebSockets, CRDT, LSEQ indexing, and WebAssembly.","icon":"💻","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

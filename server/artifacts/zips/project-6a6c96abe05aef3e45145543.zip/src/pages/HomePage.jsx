import React from 'react';
import HeroSection from '../components/sections/HeroSection';
import AboutSection from '../components/sections/AboutSection';
import FeaturedProjectsSection from '../components/sections/FeaturedProjectsSection';
import SkillsSection from '../components/sections/SkillsSection';
import AchievementsSection from '../components/sections/AchievementsSection';
import SampleSection from '../components/sections/SampleSection';
import CTASection from '../components/sections/CTASection';

export default function HomePage() {
  return (
    <div className="page-home">
      <HeroSection />
      <AboutSection />
      <FeaturedProjectsSection />
      <SkillsSection />
      <AchievementsSection />
      <SampleSection />
      <CTASection />
    </div>
  );
}

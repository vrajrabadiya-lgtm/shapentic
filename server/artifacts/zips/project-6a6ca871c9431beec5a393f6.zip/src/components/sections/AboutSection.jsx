import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function AboutSection() {
  return (
    <Section spacing="lg" className="layout-default animate-slide-up">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#003366' }}>
              About
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">About Me</h2>
            {"I'm a passionate backend software engineer and computer science student." && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto">I'm a passionate backend software engineer and computer science student.</p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"AetherWeb","desc":"High-concurrency multithreaded web server.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"AegisDB","desc":"LSM-Tree database engine.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"CoType","desc":"Distributed collaborative editor.","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

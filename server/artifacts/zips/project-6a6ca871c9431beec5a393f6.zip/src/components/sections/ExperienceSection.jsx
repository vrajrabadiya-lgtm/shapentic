import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function ExperienceSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#003366' }}>
              Experience
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Professional Experience</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"Backend Developer","desc":"Developed scalable backend systems using Node.js and Express.js.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Computer Science Student","desc":"Studied advanced algorithms, data structures, and distributed systems.","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

import React from 'react';
import StatCard from '../ui/StatCard';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Grid from '../layout/Grid';

export default function AchievementsSection() {
  const stats = [
  {
    "value": "50+",
    "label": "Enterprise Deployments",
    "description": "Production 3D interactive applications built and deployed globally.",
    "icon": "✦"
  },
  {
    "value": "5",
    "label": "Open Source Awards",
    "description": "Recognized for innovative contribution to modern WebGL architectures.",
    "icon": "✦"
  },
  {
    "value": "99.9%",
    "label": "System Reliability",
    "description": "Strict SLA compliance and bug-free resilient engineering.",
    "icon": "✦"
  },
  {
    "value": "12M+",
    "label": "Global End Users",
    "description": "Interacting daily with digital interfaces.",
    "icon": "✦"
  }
];

  return (
    <Section id="achievements" spacing="md" background="dark" divider={true}>
      <Container size="xl">
        <Grid columns={4} gap="md">
          {stats.map((s, idx) => (
            <StatCard key={idx} {...s} animation={{ delay: idx * 0.1 }} />
          ))}
        </Grid>
      </Container>
    </Section>
  );
}

import React from 'react'
import HeroLayout from '../layout/HeroLayout'
import Cinematic3DScene from '../../3d/Cinematic3DScene'

const heroData = {
  "title": "Automate Your Workflow",
  "subtitle": "Connect all your teams and essential tools in one seamless operating system engineered for velocity, security, and effortless scalable teamwork.",
  "description": "Connect all your teams and essential tools in one seamless operating system engineered for velocity, security, and effortless scalable teamwork.",
  "badge": "Next-Gen Enterprise SaaS · 99.99% Uptime",
  "alignment": "left",
  "background": "#0a0a14",
  "theme": {
    "primary": "#3d5eff",
    "secondary": "#00d4ff",
    "text": "#f8fafc"
  },
  "buttons": [
    {
      "text": "Explore 3D Platform",
      "variant": "primary"
    }
  ]
}

export default function HeroSection() {
  return (
    <HeroLayout
      {...heroData}
      scene={<Cinematic3DScene />}
    />
  )
}

import React from 'react';
import PricingCard from '../ui/PricingCard';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Grid from '../layout/Grid';
import Stack from '../layout/Stack';

export default function PricingSection() {
  const tiers = [
  {
    "title": "Tier 1",
    "price": "$0",
    "period": "",
    "features": [],
    "highlight": false,
    "button": "Select Plan"
  },
  {
    "title": "Tier 2",
    "price": "$0",
    "period": "",
    "features": [],
    "highlight": false,
    "button": "Select Plan"
  },
  {
    "title": "Tier 3",
    "price": "$0",
    "period": "",
    "features": [],
    "highlight": false,
    "button": "Select Plan"
  }
];

  return (
    <Section id="pricing" spacing="lg" divider={true}>
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-indigo-400 mb-2 block">Transparent Investment</span>
            <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-4">Pricing</h2>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">Choose a plan tailored to your operational scale.</p>
          </div>
          <Grid columns={3} gap="md" align="stretch">
            {tiers.map((tier, idx) => (
              <PricingCard key={idx} {...tier} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

import React from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from '../../theme/ThemeProvider';

export default function Navbar({ brand = "Website", links = [] }) {
  const { themeTokens } = useTheme();
  const bg = themeTokens?.colors?.surface || "#0a0a14";
  const pri = themeTokens?.colors?.primary || "#3d5eff";
  const txt = themeTokens?.colors?.text || "#f8fafc";
  const acc = themeTokens?.colors?.accent || "#bf5fff";
  const maxW = themeTokens?.spacing?.containerMax || "max-w-7xl mx-auto";

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl transition-all duration-300 border-b border-white/10" style={{ backgroundColor: `${bg}e6` }}>
      <div className={`${maxW} px-6 h-20 flex items-center justify-between`}>
        <Link to="/" className="text-2xl font-extrabold tracking-wider flex items-center gap-2" style={{ color: txt }}>
          <span className="w-3 h-3 rounded-full animate-pulse" style={{ backgroundColor: pri }}></span>
          <span>{brand}</span>
        </Link>
        <nav className="flex items-center gap-6">
          {links.map((link, idx) => {
            const name = typeof link === 'object' && link !== null ? (link.name || link.label || 'Link') : String(link);
            const path = typeof link === 'object' && link !== null ? (link.path || '/') : (link === 'Home' ? '/' : '/' + String(link).toLowerCase());
            return (
              <Link key={idx} to={path} className="text-sm font-semibold transition-colors opacity-80 hover:opacity-100" style={{ color: txt }}>
                {name}
              </Link>
            );
          })}
          <Link to="/contact" className="!py-2.5 !px-6 text-xs transition-transform transform hover:scale-105 font-bold rounded-lg text-white" style={{ backgroundColor: pri }}>
            Get Started
          </Link>
        </nav>
      </div>
    </header>
  );
}

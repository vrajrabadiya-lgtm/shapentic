import React from 'react';
import HeroSection from '../components/sections/HeroSection';
import FeaturesSection from '../components/sections/FeaturesSection';
import CTASection from '../components/sections/CTASection';
import AchievementsSection from '../components/sections/AchievementsSection';
import PricingSection from '../components/sections/PricingSection';
import FAQSection from '../components/sections/FAQSection';
import TestimonialsSection from '../components/sections/TestimonialsSection';
import SampleSection from '../components/sections/SampleSection';

export default function HomePage() {
  return (
    <div className="page-home">
      <HeroSection />
      <FeaturesSection />
      <CTASection title="Experience Supercharged Productivity" subtitle="Join thousands of high-growth modern teams utilizing automated intelligence and real-time cloud analytics." buttonText="Start Free Trial" />
      <AchievementsSection />
      <PricingSection />
      <FAQSection />
      <TestimonialsSection />
      <SampleSection />
    </div>
  );
}

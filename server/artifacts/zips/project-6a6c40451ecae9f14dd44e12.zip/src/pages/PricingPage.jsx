import React from 'react';
import Section from '../components/layout/Section';
import Container from '../components/layout/Container';
import Grid from '../components/layout/Grid';
import Stack from '../components/layout/Stack';
import PricingCard from '../components/ui/PricingCard';

export default function PricingPage() {
  const tiers = [
  {
    "title": "Standard Operational Suite",
    "price": "$49",
    "period": "/ month",
    "features": [
      "Full Core Platform Access",
      "Intuitive Interactive UI",
      "Standard Daily Usage Limits",
      "Responsive Community Support"
    ],
    "highlight": false,
    "button": "Deploy Standard Suite"
  },
  {
    "title": "Professional Premier Tier",
    "price": "$149",
    "period": "/ month",
    "features": [
      "Unlimited Interactive Workspaces",
      "Advanced Export Options",
      "Real-Time Team Concurrency",
      "Dedicated 99.99% Uptime Guarantee"
    ],
    "highlight": true,
    "button": "Deploy Professional Tier"
  },
  {
    "title": "Dedicated Enterprise Custom",
    "price": "Custom",
    "period": "/ annual",
    "features": [
      "Dedicated Account Executive Advisory",
      "Custom Security & SLA Compliance",
      "Private Air-Gapped Setup Option",
      "Direct 24/7 Senior Engineering Support"
    ],
    "highlight": false,
    "button": "Inquire Enterprise Custom"
  }
];

  return (
    <div className="page-pricing">
      <Section spacing="lg">
        <Container size="xl">
          <Stack spacing="lg">
            <div className="text-center mb-6">
              <span className="text-xs uppercase font-extrabold tracking-widest text-indigo-400 mb-2 block">Transparent Investment</span>
              <h1 className="text-5xl md:text-6xl font-black mb-4 tracking-tight text-white">Select Your Package</h1>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto">Tailored pricing packages designed to match your operational scale with zero hidden fees.</p>
            </div>
            <Grid columns={3} gap="md" align="stretch">
              {tiers.map((tier, idx) => (
                <PricingCard key={idx} {...tier} />
              ))}
            </Grid>
          </Stack>
        </Container>
      </Section>
    </div>
  );
}

import React from 'react';
import HeroSection from '../components/sections/HeroSection';
import AboutSection from '../components/sections/AboutSection';
import ExperienceSection from '../components/sections/ExperienceSection';
import FeaturedProjectsSection from '../components/sections/FeaturedProjectsSection';
import SkillsSection from '../components/sections/SkillsSection';
import AchievementsSection from '../components/sections/AchievementsSection';
import ContactSection from '../components/sections/ContactSection';
import ResumeSection from '../components/sections/ResumeSection';
import SampleSection from '../components/sections/SampleSection';
import CTASection from '../components/sections/CTASection';

export default function HomePage() {
  return (
    <div className="page-home">
      <HeroSection />
      <AboutSection />
      <ExperienceSection />
      <FeaturedProjectsSection />
      <SkillsSection />
      <AchievementsSection />
      <ContactSection />
      <ResumeSection />
      <SampleSection />
      <CTASection />
    </div>
  );
}

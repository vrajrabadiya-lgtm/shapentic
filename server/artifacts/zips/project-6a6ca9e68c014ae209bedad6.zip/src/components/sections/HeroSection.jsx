import React from 'react'
import HeroLayout from '../layout/HeroLayout'
import Cinematic3DScene from '../../3d/Cinematic3DScene'

const heroData = {
  "title": "Hi, I'm Suparn Nayak",
  "subtitle": "Backend Developer | Computer Science Student | Passionate about Scalable Systems and AI",
  "description": "Backend Developer | Computer Science Student | Passionate about Scalable Systems and AI",
  "badge": "High-End Software Engineering Portfolio",
  "alignment": "left",
  "background": "#0a0a14",
  "theme": {
    "primary": "#3d5eff",
    "secondary": "#00d4ff",
    "text": "#f0f0ff"
  },
  "buttons": [
    {
      "text": "Explore Suparn Nayak",
      "variant": "primary"
    }
  ]
}

export default function HeroSection() {
  return (
    <HeroLayout
      {...heroData}
      scene={<Cinematic3DScene />}
    />
  )
}

import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import StatCard from '../ui/StatCard';
import Grid from '../layout/Grid';

export default function AchievementsSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#001f3f' }}>
              Achievements
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Achievements</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={4} gap="md">
            {[{"val":"100%","label":"Top Performer","desc":"Recognized as a top performer in multiple projects."},{"val":"100%","label":"Innovation Award","desc":"Received an innovation award for a groundbreaking project."}].map((s, idx) => (
              <StatCard key={idx} val={s.val} label={s.label} desc={s.desc} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

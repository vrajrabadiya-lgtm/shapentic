import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function SkillsSection() {
  return (
    <Section spacing="lg" className="layout-default animate-slide-up">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#001f3f' }}>
              Skills
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Technical Skills</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"Backend Development","desc":"Expertise in building robust backend systems.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"C++","desc":"Proficient in C++ programming language.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Distributed Systems","desc":"Experience with distributed systems architecture.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Node.js","desc":"Skilled in developing applications using Node.js.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Express.js","desc":"Experienced in building web applications with Express.js.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"MongoDB","desc":"Proficient in working with MongoDB databases.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Redis","desc":"Experienced in using Redis for caching and data storage.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"BullMQ","desc":"Skilled in implementing task queues with BullMQ.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"REST APIs","desc":"Experienced in designing and developing RESTful APIs.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"React","desc":"Proficient in building user interfaces with React.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Docker","desc":"Experienced in containerization with Docker.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Git","desc":"Proficient in version control with Git.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Data Structures & Algorithms","desc":"Strong understanding of data structures and algorithms.","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

import React from 'react'
import { SceneContent } from './SceneComposer'

export default function Cinematic3DScene({ sceneId, style = {} }) {
  return (
    <SceneContent
      sceneId={sceneId || "FloatingFabricScene"}
      cameraPreset="Hero Camera"
      lightingPreset="cinematic lighting"
      interactionPreset="Morph"
      quality="High"
    />
  )
}
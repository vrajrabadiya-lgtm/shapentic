import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import Grid from '../layout/Grid';

export default function ContactSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#001f3f' }}>
              Contact
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Get in Touch</h2>
            {"Feel free to reach out to me using the form below." && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto">Feel free to reach out to me using the form below.</p>
            )}
          </div>
          
          <form className="space-y-6 bg-slate-900/60 p-8 md:p-12 rounded-3xl border border-slate-800/80 shadow-2xl" onSubmit={(e) => e.preventDefault()}>
            <Grid columns={2} gap="sm">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-2 text-slate-300">First Name</label>
                <input type="text" className="w-full px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white" placeholder="First Name" />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-2 text-slate-300">Last Name</label>
                <input type="text" className="w-full px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white" placeholder="Last Name" />
              </div>
            </Grid>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider mb-2 text-slate-300">Email Address</label>
              <input type="email" className="w-full px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white" placeholder="your-email@example.com" />
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider mb-2 text-slate-300">Message</label>
              <textarea rows={5} className="w-full px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white" placeholder="Your requirements..."></textarea>
            </div>
            <button type="submit" className="w-full py-4 px-8 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-extrabold text-lg transition text-white">Send Message</button>
          </form>
        </Stack>
      </Container>
    </Section>
  );
}

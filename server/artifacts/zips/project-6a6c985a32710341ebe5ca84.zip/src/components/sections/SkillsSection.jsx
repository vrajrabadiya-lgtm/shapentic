import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function SkillsSection() {
  return (
    <Section spacing="lg" className="layout-default animate-fade-in">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#001f3f' }}>
              Skills
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Technical Skills</h2>
            {"" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto"></p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"Backend Development","desc":"Proficient in building and maintaining backend systems.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"C++","desc":"Experienced in developing high-performance applications.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Distributed Systems","desc":"Knowledgeable in designing and implementing distributed systems.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Node.js","desc":"Skilled in building scalable and efficient web applications.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Express.js","desc":"Experienced in creating RESTful APIs.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"MongoDB","desc":"Proficient in using MongoDB for data storage.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Redis","desc":"Experienced in using Redis for caching and message brokering.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"BullMQ","desc":"Skilled in using BullMQ for managing background jobs.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"REST APIs","desc":"Proficient in designing and implementing RESTful APIs.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"React","desc":"Experienced in building user interfaces with React.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Docker","desc":"Skilled in containerizing applications with Docker.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Git","desc":"Proficient in using Git for version control.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Data Structures & Algorithms","desc":"Strong understanding of data structures and algorithms.","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

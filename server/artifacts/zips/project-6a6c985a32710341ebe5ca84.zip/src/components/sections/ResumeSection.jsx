import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function ResumeSection() {
  return (
    <Section spacing="lg" className="layout-default animate-slide-up">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#001f3f' }}>
              Resume
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">Resume</h2>
            {"Download my resume to learn more about my professional experience and skills." && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto">Download my resume to learn more about my professional experience and skills.</p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"Interdisciplinary Curriculum","desc":"Rigorous accredited degree pathways integrating sciences, arts, innovative compute models, and global leadership.","icon":"🎓","price":"","period":"","author":"","role":"","quote":""},{"title":"World-Class Research Labs","desc":"Access state-of-the-art innovation centers, interactive bioscience centers, and dedicated undergraduate research grants.","icon":"🔬","price":"","period":"","author":"","role":"","quote":""},{"title":"Global Alumni Network","desc":"Connect with over 40,000 active alumni leading multinational corporations, research institutions, and modern public governance worldwide.","icon":"🌐","price":"","period":"","author":"","role":"","quote":""},{"title":"Holistic Student Mentorship","desc":"Personalized faculty advising, career guidance counseling, and guaranteed professional industry residency incubation.","icon":"✨","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

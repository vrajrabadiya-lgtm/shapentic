import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import FeatureCard from '../ui/FeatureCard';
import Grid from '../layout/Grid';

export default function AboutSection() {
  return (
    <Section spacing="lg" className="layout-default animate-slide-up">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-10">
            <span className="text-xs uppercase font-extrabold tracking-widest text-[var(--color-primary)] mb-2 block" style={{ color: '#0a0e2a' }}>
              About
            </span>
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">About Suparn Nayak</h2>
            {"Backend Developer | Computer Science Student" && (
              <p className="text-slate-300 text-lg max-w-2xl mx-auto">Backend Developer | Computer Science Student</p>
            )}
          </div>
          
          <Grid columns={2} gap="md">
            {[{"title":"Backend Developer","desc":"Passionate about building scalable systems and AI solutions.","icon":"✦","price":"","period":"","author":"","role":"","quote":""},{"title":"Computer Science Student","desc":"Currently pursuing a degree in Computer Science.","icon":"✦","price":"","period":"","author":"","role":"","quote":""}].map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon || '⚡'} title={f.title || 'Feature'} description={f.desc || ''} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

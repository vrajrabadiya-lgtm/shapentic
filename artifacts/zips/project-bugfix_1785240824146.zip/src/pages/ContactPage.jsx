import React from 'react';
import Section from '../components/layout/Section';
import Container from '../components/layout/Container';
import Stack from '../components/layout/Stack';
import Grid from '../components/layout/Grid';

export default function ContactPage() {
  return (
    <div className="page-contact">
      <Section spacing="lg">
        <Container size="md">
          <Stack spacing="lg">
            <div className="text-center mb-4">
              <span className="text-xs uppercase font-extrabold tracking-widest text-indigo-400 mb-2 block">Direct Engagement</span>
              <h1 className="text-5xl font-black mb-4 tracking-tight text-white">Connect with Engineering Sales</h1>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto">Initiate direct discussions regarding enterprise SLA deployment, custom on-premise licensing, or technical onboarding.</p>
            </div>
            <form className="space-y-6 bg-slate-900/60 p-8 md:p-12 rounded-3xl border border-slate-800/80 shadow-2xl" onSubmit={(e) => e.preventDefault()}>
              <Grid columns={2} gap="sm">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2 text-slate-300">First Name</label>
                  <input type="text" className="w-full px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white shadow-inner" placeholder="Alex" />
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider mb-2 text-slate-300">Last Name</label>
                  <input type="text" className="w-full px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white shadow-inner" placeholder="Taylor" />
                </div>
              </Grid>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-2 text-slate-300">Email Address</label>
                <input type="email" className="w-full px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white shadow-inner" placeholder="v.vance@global-enterprise.co" />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider mb-2 text-slate-300">Message &amp; Requirements</label>
                <textarea rows={5} className="w-full px-5 py-3.5 bg-slate-950 border border-slate-700 rounded-xl focus:outline-none focus:border-indigo-500 text-white shadow-inner" placeholder="Provide details regarding your desired timeline and organizational objectives..."></textarea>
              </div>
              <button type="submit" className="w-full py-4 px-8 rounded-xl bg-indigo-600 hover:bg-indigo-500 font-extrabold text-lg transition shadow-lg shadow-indigo-600/30 text-white">Request Enterprise Consultation</button>
            </form>
          </Stack>
        </Container>
      </Section>
    </div>
  );
}

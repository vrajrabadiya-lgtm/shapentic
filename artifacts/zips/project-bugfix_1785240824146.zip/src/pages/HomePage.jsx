import React from 'react';
import HeroSection from '../components/sections/HeroSection';
import FeaturesSection from '../components/sections/FeaturesSection';
import ServicesSection from '../components/sections/ServicesSection';
import TestimonialsSection from '../components/sections/TestimonialsSection';
import FAQSection from '../components/sections/FAQSection';
import CTASection from '../components/sections/CTASection';
import ContactSection from '../components/sections/ContactSection';

export default function HomePage() {
  return (
    <div className="page-home">
      <HeroSection />
      <FeaturesSection />
      <ServicesSection />
      <TestimonialsSection />
      <FAQSection />
      <CTASection title="Build the Next Quantum Paradigm" subtitle="Harness resilient cloud computing infrastructure, generative neural models, and world-scale edge acceleration." buttonText="Get Started" />
      <ContactSection />
    </div>
  );
}

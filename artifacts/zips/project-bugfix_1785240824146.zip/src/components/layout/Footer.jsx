import React from 'react';
import { useTheme } from '../../theme/ThemeProvider';

export default function Footer({ brand = "Website", tagline = "", links = [] }) {
  const { themeTokens, theme } = useTheme();
  const bg = themeTokens?.colors?.background || "#0a0a14";
  const pri = themeTokens?.colors?.primary || "#3d5eff";
  const sec = themeTokens?.colors?.secondary || "#00d4ff";
  const txt = themeTokens?.colors?.text || "#f8fafc";
  const muted = themeTokens?.colors?.textMuted || "#94a3b8";

  return (
    <footer className="border-t py-16 px-6 text-center relative overflow-hidden transition-colors duration-300" style={{ backgroundColor: bg, borderColor: `${pri}33` }}>
      <div className="absolute inset-0 pointer-events-none opacity-15 bg-gradient-to-t from-blue-600/20 to-transparent"></div>
      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-2xl font-extrabold mb-3 inline-block" style={{ color: txt }}>{brand}</div>
        <p className="text-sm max-w-xl mx-auto mb-8 leading-relaxed font-normal" style={{ color: muted }}>{tagline}</p>
        <div className="flex flex-wrap justify-center gap-8 text-sm font-semibold mb-12" style={{ color: muted }}>
          {links.map((l, i) => <span key={i} className="cursor-pointer hover:opacity-100 opacity-80 transition-opacity" style={{ color: sec }}>{typeof l === 'string' ? l : l.name || 'Link'}</span>)}
        </div>
        <div className="text-xs border-t border-white/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4" style={{ color: `${muted}99` }}>
          <span>&copy; {new Date().getFullYear()} {brand}. All rights reserved.</span>
          <span className="px-3 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold border" style={{ backgroundColor: `${pri}1a`, borderColor: `${pri}33`, color: sec }}>Theme: {theme || 'Modern'}</span>
        </div>
      </div>
    </footer>
  );
}

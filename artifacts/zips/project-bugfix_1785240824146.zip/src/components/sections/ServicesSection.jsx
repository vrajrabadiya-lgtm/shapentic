import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Grid from '../layout/Grid';
import Stack from '../layout/Stack';

export default function ServicesSection() {
  const services = [
  {
    "title": "Autonomous Pipeline Orchestration",
    "desc": "Intelligent background agent workflows that autonomously monitor, heal, and optimize operational pipeline schemas in real-time.",
    "icon": "⚡"
  },
  {
    "title": "Zero-Latency Spatial Telemetry",
    "desc": "Hardware-accelerated rendering engine built to provide instant visual interaction and live data throughput across any device endpoint.",
    "icon": "🌐"
  },
  {
    "title": "Cryptographic SOC-2 Vaults",
    "desc": "End-to-end post-quantum encryption verifications, strict OAuth2 compliance, and distributed enterprise data redundancy.",
    "icon": "🔒"
  },
  {
    "title": "Real-time Multi-Tenant Concurrency",
    "desc": "High-frequency WebSocket synchronization enabling collaborative global enterprise operations with guaranteed state atomicity.",
    "icon": "🤝"
  }
];

  return (
    <Section id="services" spacing="lg">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-cyan-400 mb-2 block">Comprehensive Excellence</span>
            <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-4">Specialized Services &amp; Programs</h2>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto">Combining personalized professional engagement with groundbreaking high-performance standards.</p>
          </div>
          <Grid columns={2} gap="md">
            {services.map((s, idx) => (
              <div key={idx} className="p-8 rounded-3xl bg-slate-900/70 border border-slate-800 hover:border-cyan-500/40 transition-all shadow-xl flex flex-col justify-between group">
                <div>
                  <div className="flex justify-between items-start mb-6">
                    <span className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-3xl">{s.icon || '✦'}</span>
                    <span className="text-xs px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-300 font-semibold border border-cyan-500/20">{s.tag || 'Service'}</span>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-cyan-300 transition-colors">{s.title}</h3>
                  <p className="text-slate-400 leading-relaxed text-sm mb-6">{s.desc}</p>
                </div>
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2 group-hover:translate-x-2 transition-transform">Explore Offering &rarr;</span>
              </div>
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

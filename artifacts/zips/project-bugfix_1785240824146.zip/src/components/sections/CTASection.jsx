import React from 'react';
import { motion } from 'framer-motion';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';
import Button from '../ui/Button';
import { useTheme } from '../../theme/ThemeProvider';

export default function CTASection({
  title = 'Ready to Transform Your Digital Domain?',
  description = 'Partner with our specialized architecture leads to deploy high-velocity solutions today.',
  primaryButton = 'Get Started Now',
  secondaryButton = 'Schedule Consultation',
  background = 'surface',
  theme = {},
  animation = {}
}) {
  const { themeTokens } = useTheme();
  
  return (
    <Section spacing="lg" background={background} divider={true} className="relative overflow-hidden text-center">
      <div 
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{ background: `linear-gradient(to top, ${themeTokens.colors.primary}44, transparent)` }} 
      />
      <Container size="md" className="relative z-10">
        <motion.div
          initial={themeTokens.animations.fadeUp?.initial || { opacity: 0, y: 20 }}
          whileInView={themeTokens.animations.fadeUp?.whileInView || { opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <Stack spacing="lg" align="center">
            <div>
              <span 
                className="text-xs font-black uppercase tracking-widest mb-3 block"
                style={{ color: themeTokens.colors.secondary }}
              >
                Next Step
              </span>
              <h2 
                className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4"
                style={{ color: themeTokens.colors.text }}
              >
                {title}
              </h2>
              <p 
                className="text-base md:text-lg max-w-xl mx-auto leading-relaxed"
                style={{ color: themeTokens.colors.textMuted }}
              >
                {description}
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center w-full">
              <Button variant="primary" size="lg">{primaryButton}</Button>
              {secondaryButton && <Button variant="secondary" size="lg">{secondaryButton}</Button>}
            </div>
          </Stack>
        </motion.div>
      </Container>
    </Section>
  );
}

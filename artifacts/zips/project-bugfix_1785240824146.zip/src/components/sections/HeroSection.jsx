import React from 'react'
import HeroLayout from '../layout/HeroLayout'
import Cinematic3DScene from '../../3d/Cinematic3DScene'

const heroData = {
  "title": "Next-Gen Architecture by executive decision makers with",
  "subtitle": "Scalable engineering and intelligent spatial interfaces designed for unmatched operational velocity.",
  "description": "Unleash advanced system orchestration, automated end-to-end continuous deployment, and seamless interactive data visualization.",
  "badge": "Enterprise System Intelligence · v3.0 Live",
  "alignment": "left",
  "background": "#0a0a14",
  "theme": {
    "primary": "#3d5eff",
    "secondary": "#00d4ff",
    "text": "#f8fafc"
  },
  "buttons": [
    {
      "text": "Launch Architecture",
      "variant": "primary"
    },
    {
      "text": "Explore Capabilities",
      "variant": "outline"
    }
  ]
}

export default function HeroSection() {
  return (
    <HeroLayout
      {...heroData}
      scene={<Cinematic3DScene />}
    />
  )
}

import React from 'react';
import FeatureCard from '../ui/FeatureCard';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Grid from '../layout/Grid';
import Stack from '../layout/Stack';

export default function FeaturesSection() {
  const features = [
  {
    "icon": "⚡",
    "title": "Autonomous Pipeline Orchestration",
    "description": "Intelligent background agent workflows that autonomously monitor, heal, and optimize operational pipeline schemas in real-time."
  },
  {
    "icon": "🌐",
    "title": "Zero-Latency Spatial Telemetry",
    "description": "Hardware-accelerated rendering engine built to provide instant visual interaction and live data throughput across any device endpoint."
  },
  {
    "icon": "🔒",
    "title": "Cryptographic SOC-2 Vaults",
    "description": "End-to-end post-quantum encryption verifications, strict OAuth2 compliance, and distributed enterprise data redundancy."
  },
  {
    "icon": "🤝",
    "title": "Real-time Multi-Tenant Concurrency",
    "description": "High-frequency WebSocket synchronization enabling collaborative global enterprise operations with guaranteed state atomicity."
  }
];

  return (
    <Section id="features" spacing="lg">
      <Container size="xl">
        <Stack spacing="lg">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[var(--color-secondary,#00d4ff)] mb-2 block">Core Capabilities</span>
            <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-[var(--color-text,#f0f0ff)] mb-4">Built for High-Velocity Performance</h2>
            <p className="text-[var(--color-text-muted,#94a3b8)] text-lg max-w-2xl mx-auto">Engineered from the ground up to provide unrivaled reliability, visual excellence, and operational speed.</p>
          </div>
          <Grid columns={2} gap="md">
            {features.map((f, idx) => (
              <FeatureCard key={idx} icon={f.icon} title={f.title} description={f.description} animation={{ delay: idx * 0.1 }} />
            ))}
          </Grid>
        </Stack>
      </Container>
    </Section>
  );
}

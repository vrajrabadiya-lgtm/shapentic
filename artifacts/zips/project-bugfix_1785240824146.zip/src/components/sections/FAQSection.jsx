import React from 'react';
import FAQAccordion from '../ui/FAQAccordion';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';

export default function FAQSection() {
  const faqs = [
  {
    "question": "How rapidly can our engineering squad integrate this platform into our existing cloud infrastructure?",
    "answer": "Our modular architecture defaults to clean GraphQL and REST webhooks that plug directly into existing Kubernetes and Next.js enterprise stacks within 48 hours."
  },
  {
    "question": "What legal security compliance certifications does your data residency framework maintain?",
    "answer": "We maintain SOC-2 Type II, ISO 27001, and HIPAA-compliant data routing architectures across all global multi-region cloud deployment endpoints."
  },
  {
    "question": "Can we export custom WebGL and 3D interactive components directly into our proprietary React codebase?",
    "answer": "Yes. Professional and Enterprise tiers permit raw self-contained TSX and GLSL shader code extraction with full commercial distribution licensing."
  },
  {
    "question": "Is automatic horizontal load elasticity supported during extreme traffic surges?",
    "answer": "Our edge-routed serverless container grid dynamically provisions redundant runtime worker nodes within 4 milliseconds of load spike detection."
  }
];

  return (
    <Section id="faq" spacing="lg">
      <Container size="md">
        <Stack spacing="lg">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-widest text-[var(--color-secondary,#00d4ff)] mb-2 block">Clear Answers</span>
            <h2 className="text-4xl font-extrabold text-[var(--color-text,#f0f0ff)] tracking-tight mb-4">Frequently Asked Questions</h2>
            <p className="text-[var(--color-text-muted,#94a3b8)] text-base max-w-xl mx-auto">Everything you need to know about system integrations, SLA guarantees, and enterprise scalability.</p>
          </div>
          <Stack spacing="sm">
            {faqs.map((item, idx) => (
              <FAQAccordion key={idx} question={item.question} answer={item.answer} defaultOpen={idx === 0} icon="+" />
            ))}
          </Stack>
        </Stack>
      </Container>
    </Section>
  );
}

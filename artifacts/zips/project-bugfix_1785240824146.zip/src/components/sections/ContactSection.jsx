import React from 'react';
import Section from '../layout/Section';
import Container from '../layout/Container';
import Stack from '../layout/Stack';

export default function ContactSection() {
  return (
    <Section id="contact" spacing="lg">
      <Container size="md">
        <div className="p-12 md:p-16 rounded-3xl bg-gradient-to-tr from-slate-900 via-indigo-950/40 to-slate-950 border border-slate-800 shadow-2xl text-center relative overflow-hidden">
          <div className="absolute -bottom-10 -left-10 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <Stack spacing="md" align="center">
            <div>
              <span className="text-xs uppercase font-bold tracking-widest text-indigo-400 mb-3 block">Direct Communication</span>
              <h2 className="text-4xl md:text-5xl font-extrabold text-white tracking-tight mb-4">Connect with Engineering Sales</h2>
              <p className="text-slate-300 text-lg max-w-2xl mx-auto leading-relaxed">
                Initiate direct discussions regarding enterprise SLA deployment, custom on-premise licensing, or technical onboarding.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-md mx-auto w-full">
              <input type="email" placeholder="v.vance@global-enterprise.co" className="w-full px-5 py-4 bg-slate-950 border border-slate-700 rounded-2xl text-white focus:outline-none focus:border-indigo-500 transition shadow-inner" />
              <button className="w-full sm:w-auto px-8 py-4 bg-indigo-600 hover:bg-indigo-500 font-extrabold text-white rounded-2xl whitespace-nowrap shadow-lg shadow-indigo-600/30 transition duration-200">Request Enterprise Consultation</button>
            </div>
          </Stack>
        </div>
      </Container>
    </Section>
  );
}

import React from 'react'
import { SceneContent } from './SceneComposer'

export default function Cinematic3DScene({ sceneId, style = {} }) {
  return (
    <SceneContent
      sceneId={sceneId || "DashboardScene"}
      cameraPreset="Hero Camera"
      lightingPreset="Studio"
      interactionPreset="Hover Rotation"
      quality="High"
    />
  )
}
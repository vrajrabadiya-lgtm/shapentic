import React from 'react';
import { Environment } from '@react-three/drei';

export default function LightingPresets({ preset = "Studio", primaryColor = "#3b82f6", secondaryColor = "#10b981" }) {
  switch (preset) {
    case "Apple":
      return (
        <>
          <ambientLight intensity={0.7} color="#ffffff" />
          <directionalLight position={[10, 10, 5]} intensity={2.5} color="#ffffff" castShadow />
          <pointLight position={[-10, -10, -5]} intensity={0.8} color="#e2e8f0" />
          <Environment preset="city" />
        </>
      );
    case "Neon":
      return (
        <>
          <ambientLight intensity={0.15} color="#0a0a14" />
          <pointLight position={[8, 8, 8]} intensity={5.0} color="#38bdf8" decay={2} />
          <pointLight position={[-8, -5, -6]} intensity={4.5} color="#f43f5e" decay={2} />
          <spotLight position={[0, 15, 5]} intensity={6.0} color="#a855f7" angle={0.4} />
        </>
      );
    case "Cinematic":
      return (
        <>
          <ambientLight intensity={0.25} />
          <spotLight position={[5, 12, 8]} intensity={4.0} color={primaryColor} angle={0.45} penumbra={1} castShadow />
          <directionalLight position={[-8, 3, -5]} intensity={1.5} color={secondaryColor} />
          <pointLight position={[0, -8, 4]} intensity={1.0} color="#ffffff" />
        </>
      );
    case "Sunset":
      return (
        <>
          <ambientLight intensity={0.5} color="#f59e0b" />
          <directionalLight position={[12, 6, 8]} intensity={3.0} color="#f97316" castShadow />
          <pointLight position={[-8, 4, -4]} intensity={2.0} color="#ec4899" />
          <Environment preset="sunset" />
        </>
      );
    case "Dark Tech":
      return (
        <>
          <ambientLight intensity={0.18} color="#030712" />
          <directionalLight position={[10, 10, 10]} intensity={2.8} color="#3b82f6" />
          <pointLight position={[-10, -10, -10]} intensity={1.5} color="#06b6d4" />
          <pointLight position={[0, 0, 6]} intensity={1.2} color="#6366f1" />
        </>
      );
    case "Glass":
      return (
        <>
          <ambientLight intensity={0.8} color="#ffffff" />
          <directionalLight position={[5, 10, 7]} intensity={3.2} color="#ffffff" />
          <directionalLight position={[-5, -8, -5]} intensity={1.5} color="#94a3b8" />
          <Environment preset="studio" />
        </>
      );
    case "Studio":
    default:
      return (
        <>
          <ambientLight intensity={0.6} />
          <directionalLight position={[8, 12, 8]} intensity={2.2} color="#ffffff" castShadow />
          <pointLight position={[-8, -8, -8]} intensity={0.9} color={primaryColor} />
          <Environment preset="neutral" />
        </>
      );
  }
}
